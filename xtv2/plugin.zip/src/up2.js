load('config.js');

function execute(url, page) {