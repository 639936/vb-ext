load("voice_list.js");

function execute() {
    return Response.success(voices);
}