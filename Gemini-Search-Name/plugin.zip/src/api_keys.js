// Dán các API Key của bạn vào trong mảng dưới đây.
// Bạn có thể thêm bao nhiêu key tùy thích.
// Extension sẽ tự động thử key tiếp theo nếu key trước đó thất bại.
let apiKeys = [
    "AIzaSyDgovtoLcEZ5TWZ8Hnt36zBvFk5OZQWSww",    // <-- THAY KEY CỦA BẠN VÀO ĐÂY
    "AIzaSyCs6IyDrVqtKuc3cXyIDX6BJEvshnoszVE"   // <-- THAY KEY THỨ HAI (NẾU CÓ)
];