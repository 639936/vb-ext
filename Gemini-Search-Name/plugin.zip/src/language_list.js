let languages = [
    // --- Ngôn ngữ Nguồn ---
    {"id": "zh", "name": "Nguồn: Tiếng Trung"},
    {"id": "en", "name": "Nguồn: Tiếng Anh"},
    {"id": "vi", "name": "Nguồn: Tiếng Việt"},
    
    // --- Chế độ Dịch (Đích) ---
    {"id": "vi-general", "name": "Đích: Việt - Phổ thông"},
    {"id": "vi-tienhiep", "name": "Đích: Việt - Tiên Hiệp"},
    {"id": "vi-huyenhuyen", "name": "Đích: Việt - Huyền Huyễn"},
    {"id": "vi-dothi", "name": "Đích: Việt - Đô Thị"},
    {"id": "vi-sac", "name": "Đích: Việt - Sắc Hiệp"},
    {"id": "vi-trinhtham", "name": "Đích: Việt - Trinh Thám"},
    {"id": "vi-analyzer", "name": "Đích: Phân tích Tên/VP/Luật"}
];