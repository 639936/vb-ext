// translate.js (PHIÊN BẢN THỬ NGHIỆM - Quy trình Tổng quát)
load("language_list.js"); 
load("apikey.js");
load("prompt.js");

// =======================================================================
// --- KHU VỰC CẤU HÌNH THỬ NGHIỆM ---
// =======================================================================

var testText = `
第四章 肏出个未来
看着自已的鸡巴被妍妈妈的双脚摩擦，那丝滑的触感和视觉的冲击，让他有一种别样的兴奋。
薛妍也停止了催促，睁大眼睛看着这一幕。
这样她明明没有什么快感，但看着儿子用他的大鸡巴这样“日”自已的双脚，心里居然也产生了一种不一样的兴奋。
摩擦了好一会，王越才放过薛妍的双脚，说道：“妈，咱们玩一些新鲜的好不好？”
“什么新鲜的？”薛妍问道。
王越伏下身子，在薛妍的耳边轻声说了几句。
“臭小子，这是什么鬼花样？”薛妍俏脸通红地娇嗔了一句，却还是答应了王越的要求：“坐下吧。”
“谢谢妈妈。”王越开心地在床边坐了下来，双腿分开，大鸡巴高高挺立。
薛妍则起身下了床，来到王越的双腿之间，跪了下来，双手将自已那一对水滴状的大奶子托住，身子往前一凑，用奶子把王越的鸡巴轻轻夹住。
“好妈妈，就是这样，上下动一动。”王越兴奋地指挥着。
薛妍依言上下活动双手，用奶子来回套弄着他的鸡巴。
说实话，这样用奶子套弄鸡巴，快感远不如肏屄来的爽快，但是看着自已紫红色的大鸡巴在妈妈雪白的大奶子中间来回穿梭，心理上的满足却是巨大的。
薛妍低头看着自已胸前，美目迷离。
王越这根大鸡巴，她当真是越看越爱，恨不得一口把它吞下去。
然后，她就真的这么做了，放开奶子，张开小嘴，一口含了上去。
“妈，不用含那么深，你可以一边吸，一边用舌头舔一舔。”学习了一肚子知识的王越开始反过来指挥薛妍。
薛妍依言往上抬了抬头，不再试图把整根鸡巴都含进去，而是只留下在个龟头噙在小嘴里，然后按王越说的，一边吸吮着，一边用香软的小舌头在龟头上打着转儿。
“嘶……好舒服，妈，你做的真好！”王越毫不吝惜对薛妍的夸赞。
得到王越的鼓励，薛妍顿时吸得更起劲儿了。
被妈妈温软的小嘴裹着，舌头还在敏感的龟头上来回舔舐，王越不禁爽得直吸凉气。
不过在有了几次经验后，他的耐久度也明显大增，薛妍一口气帮他吃了差不多有五分钟，小嘴都有些麻木了，他却一点想射的迹象都没有。
“妈，您先起来，该儿子伺候您了。”王越怜惜的让薛妍停止帮自已口交，待她起身后又说道：“来，您趴在床上。”
“你到底想玩什么花样？”薛妍有些不满地说道，和王越互动这么久，她的屄早已痒的不行了，现在只想让他把鸡巴插进来，狠狠的肏自已一番。
“妈，您就听我的吧，一会保证让您满意。”王越笑着说道。
薛妍拗不过他，只好在床上趴下。
看着妈妈美妙的背臀曲线，王越忍不住咽了口口水。
那双笔直而修长的黑丝美腿，自然是性感之极，但更加诱人的，却还是她那雪白、浑圆、挺翘，两只臀瓣就如同两轮满月般饱满的肥美大屁股。
哪怕此时平趴在床上，那大白屁股的曲线仍高高耸起，似乎在诱惑着他狠狠的蹂躏一番。
就和薛妍刚才想把王越的大鸡巴一口吞下一样，王越此时也有一种在这性感无双的大屁股上狠狠咬一口的冲动。
王越当然不会真的这么做，他只是爬上床去，双手抱住薛妍的腰肢，往上一提。
薛妍顿时由趴着的姿势变成了趴跪着，肥美的大屁股高高撅起，更加性感到要人老命。
“你……你干什么？”薛妍只凭想象就知道，自已此时的姿势有多么的淫荡，顿时羞得把脸深深的埋进床铺间。
“妈，我要从后面肏你。”王越嘿嘿笑着说道。
“啊……”薛妍不由发出一声羞涩的呻吟，撅着屁股被他从后面肏，不就跟动物交配的姿势一样吗？那也太羞人了！
然而不等薛妍反对，王越便从后面贴了上来，挺着大鸡巴顶进她的股沟，硕大的龟头重重压在她淫水泛滥的小骚屄上。
饥渴不已的小骚屄得到鸡巴的抚慰，薛妍顿时魂飞天外，哪还顾得上什么害羞，呢喃着说道：“乖儿子，快肏我！”
王越找准位置，轻轻往前一顶，鸡蛋大的龟头塞进薛妍紧窄的嫩屄中。
“哦——”薛妍爽得长叫一声，心里期待着王越进一步的深入和接下来痛快的抽插。
可是王越并没有如她所愿，居然只用龟头在她屄口处做着浅浅的抽插，同时双手穿过她的腰肢，捉住她一对大奶子，搓揉个不停。
虽然被双管齐下的玩弄着，但薛妍非但不满意，反而更加渴望难耐了。
那没顶的欲火让她彻底抛却了所有的矜持，回过头，美目中满是渴望的看着王越，央求道：“好儿子，妈求你了，快用力把你的大鸡巴全插进来，狠狠的肏我！”
王越这才用力一挺，大鸡巴“滋”的一声直插到底。
“啊——”薛妍爽叫一声，忍不住开始主动往后一下一下地耸动着自已的大屁股，让王越的鸡巴在自已屄里来回摩擦，只觉得自已屄里每一分嫩肉都被他的鸡巴抚慰着，巨大的快感让她简直想要发疯。
“哦……乖儿子……好儿子……你的鸡巴……太棒啦……妈被你肏的……好痛快……妈的屄都要……爽死啦……用力……用力肏妈妈……”
王越也是爽得不行，双手紧握着薛妍的大奶子，腰部挺耸，一下重似一下地用鸡巴狠肏着薛妍的小骚屄。
一边肏，王越还一边使坏地问道：“妈，告诉我，我爸有没有用这种姿势肏过你？”
“啊？”听王越突然提到他爸，薛妍顿时浑身一震，强烈的愧疚与不安瞬间涌上她的心头。
但与此同时，一种因为背德而产生的兴奋也随之而起。
王越一边继续肏着，一边问道：“快说啊，我爸有没有用这个姿势肏过你。”
“没……没有，我们只会一种姿势，求求你别问啦。”薛妍又是羞愧，又是兴奋地说道。
王越却仍不放过她：“好妈妈，告诉我，我爸的鸡巴有没有我的大，是他肏你肏的舒服，还是我肏你肏的舒服，你更喜欢被谁日？”
薛妍被王越的大鸡巴一下一下地撞击着花心，无边的快感和那种因为禁忌而产生的兴奋让她整个人都快要疯掉了，直接说出了内心最深处的渴望：“你的鸡巴更大……也是……你肏的更舒服……乖儿……别再问了……快……快肏我……啊……用力肏妈的屄……妈只喜欢……被你肏……往后……一辈子……也只给你一个人肏……好儿子……快用力……”
王越听得兴奋之极，大叫一声：“好妈妈，我爱你！”
说着，大鸡巴重重往里一顶，再次顶到了薛妍的花心上。
但这一次，他并没有再抽出来，而是继续用力，重重地往花心上一撞。
“呃……啊……”薛妍顿时发出一声不知道是舒服还是痛苦的尖叫，只觉得王越的龟头顶开了自已的花心，来到了从未有人到达过的深处。
一时间，酥、麻、酸、痒，还有微微疼痛的感觉一齐出现，让她浑身都不可控制地哆嗦起来。
与此同时，王越也爽到极致。
这是他第一次把整根鸡巴都插入薛妍的屄里，那种全部被屄里的嫩肉包夹的感觉简直爽到没边。
特别是龟头，此时整个陷入一张柔软无比、滑腻之极的小嘴中，被它紧紧吸住，那极致的体验让王越差点直接射出来。
停顿片刻，王越又有了动作，并没有往外抽出，而是用小腹紧紧顶着薛妍的大屁股，转动腰肢，用鸡巴在她的屄里研磨起来。
“啊……啊……啊……啊……”被巨大的龟头顶在花心里面不住研磨，那五味杂陈所带来的没顶快感让薛妍连说话的能力都失去了，只是在喉间发出一声声无意识的呻吟。
一口气磨了十几圈，王越才开始往后退，却感觉花心上那个小嘴竟紧紧地吸住了他的鸡巴，让他微微用力，才从里面拔出来。
而在拔出来的时候，里面竟发出“啵”的一声轻响。
薛妍这才缓过一口气来，说道：“乖儿子，你这一下可要了妈的命啦。”
“妈，这样舒服吗？”王越问道，这一招，还是他从那些资料上看到的，不过那上面也说，这种超级深入的插法，有些女人能承受，并产生强烈的快感，有些女人却承受不了，他也不知道妍妈妈能不能承受这种日法。
“狠心的坏小子，你刚才都要肏到妈的子宫里去啦，也不怕把妈日坏！”薛妍说道，然后话锋一转：“不过，真的好痛快，妈喜欢被你这样日。”
“妈，咱们继续！”知道妍妈妈能够承受这种日法，王越兴奋不已，毕竟不能尽根插入，是一件很不爽的事，而且龟头被花心里的小嘴紧紧吸住的感觉，简直太爽了。
说完，王越继续往后退了一下，整根鸡巴几乎完全拔出，只留下一个龟头还留在薛妍的屄里，然后又猛的往前一挺，鸡巴再次尽根而入，深深顶进她的花心。
薛妍再次爽得浑身一哆嗦，口中却说道：“对，乖儿子，就这样日，妈好痛快！”
王越不再说话，开始全力进攻，狂抽猛插，每次都把鸡巴几乎全部拔出，然后再全部插进去，速度越来越快。
“好儿子……会肏屄的……大鸡巴……乖儿子……妈好痛快……妈的屄……被你肏得……太爽啦……快用力肏……妈要……飞上天啦……再用力一些……哦……太爽了……妈要被你……肏死了……爽死妈了……”薛妍被肏得舒爽之极，再也没有半点矜持，把心里的感觉都大声地喊了出来。
王越一边享受着鸡巴被妍妈妈的小嫩屄紧紧包夹的快感，一边欣赏着她那肥美性感的大屁股被自已的小腹撞出的一波波臀浪，耳中还听着她的淫声浪语，也不禁魂飞天外，肏得越来越大力。
在王越的猛烈攻击下，特别是每一次龟头都撞进花心所带来的巨大快感，才刚刚被肏了两百多下，薛妍就已经达到的快乐的巅峰。
“好儿子……妈要来了……妈要泄给……大鸡巴乖儿子了……儿子……快……用力肏……把妈的高潮……肏出来……”
王越闻言，不再抽插，只是把龟头深深顶进薛妍的花心里，死死抵在里面，拼命的研磨。
“啊……啊……啊……”致命的快感瞬间没顶，薛妍的屄里一阵地震般的颤抖，然后紧紧地吸住了王越的大鸡巴。
这一刻，王越只感觉妍妈妈花心里的那张小嘴把自已的龟头咬得死紧，还大力的吸吮着，也忍不住浑身一颤，开始了强劲的喷射。
一股，两股，三股……
一连七八股浓稠而炽热的精液，带着强劲的冲击力，一滴不剩地全部喷洒进那孕育过自已两位姐姐和一个妹妹的子宫里。
被王越的精液这么一浇，本就在高潮中的薛妍，快感瞬间又达到了一个新的高度，整个人都僵住不能动了。
如此足足持续了快一分钟，薛妍那致命的快感才逐渐散去，身体发软，整个人趴倒在床上。
王越顺势压在妍妈妈性感的娇躯上，大鸡巴仍深深的停留在她的嫩屄深处。
一时间，房间里安静了下来，只剩下二人体内的真气，通过交合处，按照双修的路线快速地自动运行着。
这功法很是奇妙，双方得到的快感越强烈，它运行的速度便越快。
这一次，二人虽然只做了短短几分钟的时间，但体内的真气竟再次进步不少。
又过了几分钟，薛妍才从高潮的余韵中清醒过来，却感觉到王越的鸡巴仍坚硬如铁，在自已屄里随着脉搏一下下跳动。
这让她忍不住回味刚才那绝顶的快感，刚刚高潮过的小嫩屄居然又开始痒了起来。
“乖儿子，你肏得妈舒服死了，咱们再来一次好不好？”贪恋快感的薛妍忍不住主动求欢。
“好啊。”王越欣然应允：“咱们再换个姿势，这一次，你在上面好不好？”
“我在……上面？”薛妍有些不明白王越的意思。
王越也不多说，直接起身，将鸡巴从她体内拔出来，翻身躺在床上，大鸡巴朝天挺着。
“妈，你骑上来，用你的屄套住我的鸡巴。”王越指着自已坚挺的大鸡巴说道：“这样你就可以掌握主动啦。”
“骑上去？”薛妍从未用过这个姿势，但想想，却觉得可行，于是站起身来，分开一双被黑丝包裹着的大长腿，跨骑在王越身体身体两侧，再慢慢的蹲下。
结果还没等到位，一大滩混合着王越的精液和自已的淫水的液体，便从薛妍那被王越的大鸡巴肏得越发红嫩晶莹的屄洞里流了出来。
“呀！”薛妍不禁羞得满脸通红。
好在王越动作够快，立马从床头抽出几张纸巾，也不递给薛妍，而是拿着直接捂在她的屄上。
由于液体太多，王越一连换了四次，足足湿透了十几张纸巾，薛妍的屄里才终于不再有液体流出。
见王越一脸坏笑的看着自已，薛妍不禁羞红着脸娇嗔道：“臭小子，笑什么，还不都是你这个坏东西射进来的。”
“那也怪你啊。”王越嘿嘿笑道：“都是妈你太美太性感了，我才会射这么多的。”
“哼！那你就再多射些好了，妈倒要看看，你到底有多少。”薛妍说着，一把抓住王越的鸡巴，顶在自已屄上，大屁股用力往下一坐，滋的一声，尽根而入。
“哦……”母子二人同时爽叫一声，王越笑着说道：“妈，你这不是挺熟练的嘛，真的是第一次用这个姿势？”
“这又没什么难度，妈又这么聪明，难道还需要研究一番吗？”薛妍有些得意的说道，然后促狭一笑：“坏儿子，现在是你肏妈，还是妈在肏你呀？”
王越嘿嘿笑道：“反正都是两个人爽，谁肏谁还不一样？”
薛妍娇哼一声，开始动作起来，无师自通的不断将自已浑圆的大屁股抬起落下，用自已紧窄的小嫩屄套弄着王越的鸡巴。
王越尽情地欣赏着妍妈妈主动的媚态，见她胸前那对水滴状的大奶子随着她的动作不断跳跃，忍不住伸手将它们捉住，不断地把玩。
由于可以自已掌握主动权，而不是像刚才一样只能被动挨肏，这一次薛妍倒是支撑的时间长了一些，足足套弄了五百多下，才又一次达到高潮。
而随着她的高潮，王越也又一次把精液射满了她的子宫，量丝毫不比第一次少。
薛妍发现，儿子的持久力并不是太强，每次自已高潮，他都会跟着一起射出来。
不过这样更好，因为被内射喷洒，不但男人舒服，女人也能得到更大的快感。
当然，最主要还是王越每次射完都能很快再硬起来，如果他射一次后就疲软了，薛妍恐怕就要想办法提升他的耐久度了。
接下来，两人又一连做了三次，每一次王越都会用精液把薛妍的子宫灌满，如果不是武者到了炼气境就可以控制生命力，恐怕薛妍还真有怀上的危险。
直到现在，薛妍仍坚信自已只爱王京，所以虽然彻底迷恋上了被王越肏的快乐，但给他生孩子这种事却从未考虑过。
更何况二人的关系也根本不允许。
王越现在会的姿势足有几十种，虽然有心和妍妈妈全部试一遍，但奈何她五次之后就有些无法再承受了，只能以后慢慢来。
那双修功法当真神奇，两人做了这五次，王越的修为居然又连升两级，达到了凝神境七层。
薛妍倒是没有再升级，只是从初入凝神境九层达到了九层巅峰。
不过这也在二人的意料之中，因为每个大境界之间的差距都是一条不可逾越的鸿沟，所以大境界之间的突破也无比困难，有些人在一个境界的巅峰卡一辈子都不是什么稀罕事。
激情过后，母子二人相拥而卧，下体却仍紧紧的连在一起，因为只有这样，双修功法才会在他们体内循环流转。
“好儿子，妈越来越离不开你了。”薛妍看着王越那还带着稚气，却因为遗传了他妈妈优秀的基因而无比俊美的脸庞，由衷地说道。
她不认为自已是爱上了王越，但如果让她从此和王越分开，她肯定会比三年前丈夫失踪还要难过。
王越道：“那就不离开啊，好妈妈，咱们一辈子都在一起！”
“好，一辈子都在一起。”薛妍喃喃道：“不但是我，最好家里人都永远在一起，谁也不离开。”
“妈，您这是在鼓励我把家里的女人都给肏了吗？”王越笑问道。
不料薛妍竟点了点头：“如果真能这样，当然再好不过啦。”
“？”王越一脑袋的问号。
“乖儿子，妈没有说笑，之前我说不希望家里的女人和别人联姻，除了不希望她们受委屈之外，其实还有一个原因。”薛妍道。
王越问道：“还有什么原因？”
薛妍并没有回答，而是反过来问道：“你觉得，各家族和势力之间相互联姻，目的是什么？”
“为了武学不至于泛滥吧。”王越想都没想的回答道。
“那大家为什么不希望武学泛滥呢，毕竟全民习武可是一件大好事，足以使得人类再次压下兽族，重新成为世界的主导。”薛妍循循善诱着。
“如果全民皆武，这些家族和势力就会失去现有的地位吧。”王越思索着回答，突然明白了：“所以，各势力联姻也是为了维持自已的势力。”
“对啦，乖儿子真聪明！”薛妍夸赞了一句，然后说道：“但我觉得，咱们家以后就不用这种方式维持家族啦。”
“为什么？”王越问道。
“傻孩子，当然是因为你啦。”薛妍给了王越一个“你真笨”的眼神：“妈才被你肏了两夜，修为就从凝神境七层提升到了九层巅峰，如果你不嫌弃妈妈，以后还和妈妈肏屄，相信用不了多久，妈妈就能提升到地阙境、天元境，甚至更高的境界。”
王越急忙表态：“妈，我怎么会嫌弃您，只要您不反对，儿子以后天天都来和您肏屄！”
“小笨蛋，你怎么还不明白。”薛妍无奈道：“妈可以这样，别人也可以呀，如果你把咱们家的女人都肏了，以后咱们家就可以有一堆天元境甚至更高的强者，那时就算面对那些武学圣地，咱们也不用怕了吧！”
王越呆了一呆，这种操作，他还真的没想过。
知道三年后会有一场危机的他，确实想过很多办法，却只想到找个人双修，把自已的修为提升上去，三年内达到归真境。
没想到妍妈妈居然发散思维，想到了这个全家提升的主意。
凭心而论，这确实是个好主意，毕竟只凭王越一个人，就算再怎么强大，也很难护住全家的人。
而如果让她们都成为高手高手高高手的话，那么一切问题就都不存在了。
可是，以这样的方式提升，王越总感觉有些怪怪的，这算什么？肏出个未来吗？
别有还好说，可家里的这些女人大部分都和自已有着至亲的血缘关系，如果和她们……
那不就是乱伦吗？
`;
var testFrom = 'zh';
// Thay đổi 'testTo' để kiểm tra các quy trình khác nhau:
// 'default' hoặc 'vi_sac' -> Sẽ kích hoạt quy trình phiên âm Hán Việt.
// 'vi_vietlai' hoặc 'en_literary' -> Sẽ bỏ qua quy trình phiên âm.
var testTo = 'vi_sac';

// =======================================================================
// --- KẾT THÚC KHU VỰC CẤU HÌNH ---
// =======================================================================

var currentKeyIndex = 0;

function callGeminiAPI(text, prompt, apiKey) {
    if (!apiKey) { return { status: "error", message: "API Key không hợp lệ." }; }
    if (!text || text.trim() === '') { return { status: "success", data: "" }; }
    var full_prompt = prompt + "\n\n---\n\n" + text;
    var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" + apiKey;
    var body = {
        "contents": [{ "parts": [{ "text": full_prompt }] }],
        "generationConfig": { "temperature": 0.75, "topP": 0.95, "maxOutputTokens": 65536 },
        "safetySettings": [
            { "category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE" }
        ]
    };
    try {
        var response = fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        if (response.ok) {
            var result = JSON.parse(response.text());
            if (result.candidates && result.candidates.length > 0 && result.candidates[0].content) {
                return { status: "success", data: result.candidates[0].content.parts[0].text.trim() };
            }
            if (result.promptFeedback && result.promptFeedback.blockReason) {
                return { status: "blocked", message: "Bị chặn bởi Safety Settings: " + result.promptFeedback.blockReason };
            }
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + response.text() };
        } else {
            return { status: "key_error", message: "Lỗi HTTP " + response.status + " (API key có thể sai hoặc hết hạn mức)." };
        }
    } catch (e) {
        return { status: "error", message: "Ngoại lệ Javascript: " + e.toString() };
    }
}

// Hàm dịch từng dòng
function translateInChunksByLine(text, prompt) {
    var lines = text.split('\n');
    var translatedLines = [];
    var errorOccurred = false;
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.trim() === '') { translatedLines.push(''); continue; }
        var lineTranslated = false;
        for (var j = 0; j < apiKeys.length; j++) {
            var key = apiKeys[currentKeyIndex];
            var result = callGeminiAPI(line, prompt, key);
            if (result.status === "success") { translatedLines.push(result.data); lineTranslated = true; break; }
            if (result.status === "blocked") { translatedLines.push("..."); lineTranslated = true; break; }
            if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
            else { translatedLines.push("[LỖI DỊCH DÒNG: " + result.message + "]"); lineTranslated = true; errorOccurred = true; break; }
        }
        if (!lineTranslated) { translatedLines.push("[LỖI: TẤT CẢ API KEY ĐỀU KHÔNG HOẠT ĐỘNG]"); errorOccurred = true; }
    }
    if (errorOccurred) { return { status: "partial_error", data: translatedLines.join('\n') }; }
    return { status: "success", data: translatedLines.join('\n') };
}

function translateSingleChunk(chunkText, prompt, isPinyinRoute) {
    for (var i = 0; i < apiKeys.length; i++) {
        var key = apiKeys[currentKeyIndex];
        var result = callGeminiAPI(chunkText, prompt, key);
        if (result.status === "success") { return result; }
        if (result.status === "blocked") {
            if (isPinyinRoute) {
                 // Nếu là route phiên âm, không thử lại, chỉ báo lỗi
                return result;
            } else {
                // Nếu là route thường, thử lại bằng cách dịch từng dòng
                return translateInChunksByLine(chunkText, prompt);
            }
        }
        if (result.status === "key_error") {
            currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length;
        } else {
            return result;
        }
    }
    return { status: "error", message: "Tất cả các API key đều không hoạt động." };
}

function execute(text, from, to) {
    // ---- GHI ĐÈ DỮ LIỆU TỪ ỨNG DỤNG BẰNG DỮ LIỆU THỬ NGHIỆM ----
    text = testText;
    from = testFrom;
    to = testTo;
    console.log("!!! CHẾ ĐỘ THỬ NGHIỆM ĐANG BẬT !!! Đang sử dụng dữ liệu được khai báo trong file. Đích: " + to);
    // -----------------------------------------------------------

    if (!apiKeys || apiKeys.length === 0 || (apiKeys[0].indexOf("YOUR_GEMINI_API_KEY") !== -1)) {
        return Response.error("Vui lòng cấu hình API key trong file apikey.js.");
    }
    if (!text || text.trim() === '') { return Response.success("?"); }

    var selectedPrompt = prompts[to] || prompts["vi"];
    var processedText;
    var isPinyinRoute = false; // Cờ để nhận biết đang dùng route nào

    if (to === 'vi' || to === 'vi_sac') {
        isPinyinRoute = true;
        console.log("Phát hiện ngôn ngữ đích '" + to + "'. Bắt đầu quy trình phiên âm Hán Việt...");
        try {
            load("phienam.js");
            processedText = phienAmToHanViet(text);
        } catch (e) {
            return Response.error("LỖI: Không thể tải file phienam.js.");
        }
    } else {
        isPinyinRoute = false;
        console.log("Ngôn ngữ đích '" + to + "' không yêu cầu phiên âm. Giữ nguyên văn bản gốc.");
        processedText = text;
    }

    var textChunks = [];
    var CHUNK_SIZE = 5000;
    var MIN_LAST_CHUNK_SIZE = 1000;
    var INPUT_LENGTH_THRESHOLD = 10000;

    if (processedText.length > INPUT_LENGTH_THRESHOLD) {
        var tempChunks = [];
        for (var i = 0; i < processedText.length; i += CHUNK_SIZE) { tempChunks.push(processedText.substring(i, i + CHUNK_SIZE)); }
        if (tempChunks.length > 1 && tempChunks[tempChunks.length - 1].length < MIN_LAST_CHUNK_SIZE) {
            var lastChunk = tempChunks.pop();
            var secondLastChunk = tempChunks.pop();
            tempChunks.push(secondLastChunk + lastChunk);
        }
        textChunks = tempChunks;
    } else {
        textChunks.push(processedText);
    }

    var finalParts = [];
    for (var k = 0; k < textChunks.length; k++) {
        var chunkResult = translateSingleChunk(textChunks[k], selectedPrompt, isPinyinRoute);
        if (chunkResult.status === 'success' || chunkResult.status === 'partial_error') {
            finalParts.push(chunkResult.data);
        } else {
            var errorString = "\n\n<<<<<--- LỖI DỊCH PHẦN " + (k + 1) + " --->>>>>\n" +
                              "Lý do: " + chunkResult.message + "\n" +
                              "<<<<<--- KẾT THÚC LỖI --->>>>>\n\n";
            finalParts.push(errorString);
        }
    }
    
    var intermediateContent = finalParts.join('\n\n');
    var lines = intermediateContent.split('\n');
    var finalOutput = "";
    for (var i = 0; i < lines.length; i++) {
        finalOutput += lines[i] + "\n";
    }

    return Response.success(finalOutput.trim());
}