// translate_test.js (Phiên bản Thử nghiệm Cuối cùng - Tích hợp toàn bộ logic)
load("language_list.js"); 
load("apikey.js");
load("prompt.js");
load("baidutranslate.js"); // Tải logic của Baidu Translate

// =======================================================================
// --- KHU VỰC CẤU HÌNH THỬ NGHIỆM ---
// --- Chỉ cần thay đổi nội dung trong 3 biến dưới đây để thử nghiệm ---
// =======================================================================

// 1. Dán văn bản bạn muốn thử nghiệm vào giữa hai dấu ` `
// VÍ DỤ 1 (Văn bản ngắn để kiểm tra Baidu Translate và logic hiển thị):
var testText = ` 紧！真的太紧了！前所未有的紧！肉棒明明才堪堪插入四分之一的深度而已，但是里面那种被细嫩软肉所紧夹的感觉，却几乎让牛奕辰射出来。也不知是魅魔的外挂，还是宋祖儿自身携带的天赋，明明是第一次给她开苞而已，但是幼女那水光润滑的阴道就像是活过来了一样，像是无数张婴儿的小嘴，不断的缠绕、嗫咬他的肉棒。“呼……”牛奕辰再次长出一口气，稳了稳心神，将肉棒继续往宋祖儿的阴道里面插去。粗大的肉棒已经将宋祖儿阴道口撑到了最大，阴唇边缘变成了薄薄的一层，似乎再用一点力气就要撑裂一样。坚硬的龟头在撑开宋祖儿紧窄粉嫩的蜜穴的同时，她那两瓣阴唇也紧紧的拉扯着牛奕辰肉棒的表皮，以致于都让他略微有点发疼。这种肉棒被紧紧夹住，仿佛一寸都不能动的感觉，是只有宋祖儿这个年龄的小萝莉才能让人体会到的。但也正是这种‘痛感’，让牛奕辰充满怜惜的看向了宋祖儿的小脸。连他都感觉疼，那宋祖儿这个小萝莉又是什么感觉呢？“呼哧……呼哧……”宋祖儿轻咬住自己嫩红的小嘴，小巧的鼻梁快速颤抖着，额头上又沁出了几滴香汗，这香汗顺着她精致的脸庞一路淌下，竟然低落到了她浅色的乳头上面，晶莹剔透的，无比诱人。随着这股汗水，一股香甜的，仿佛带着奶味儿的香气扑面而来。这是独属于小萝莉的体香。闻着这动人的香味儿，原本才升起一点怜惜之情的牛奕辰欲念更炽，肉棒下压的力度，不由的便加大了许多。“啊！”宋祖儿发出了一声清脆的尖叫，原本抱着自己双腿的小手一松，整个人躺倒在床上，双腿也自然的放在了牛奕辰的肩头。“哥哥……啊……”宋祖儿贝齿轻咬，发出一声抽气，小猫一样的眼睛里又蓄满了泪水，“不能插……到最里面了……”牛奕辰也感觉到了小萝莉阴道最深处的花蕊，但是低头看去，肉棒还有足足三分之一在外面，没有插进去呢。“哥哥……”宋祖儿低低的喊了牛奕辰一声，声音闷闷的，好像下一秒就会哭出来一样。“好了，我的涓涓宝贝儿，我不往里插了。”牛奕辰俯身想要亲一亲她，然后尴尬的发现，因为体型的缘故，他就算是弯下腰，也亲不住宋祖儿的脸，最多也就是亲一亲她的头顶……这发现一开始让牛奕辰尴尬，但是很快，这种尴尬又转化为了刺激，让他忍不住想要在宋祖儿稚嫩的腔道之中来回抽送，想要看到这小女孩儿被操上高潮之后的样子。只是牛奕辰终究还是有几分冷静的，就算是心里激动，面对幼女的他也还是非常小心。在安慰了几句之后，牛奕辰轻轻的将肉棒从宋祖儿的阴道里向外抽，直到抽到龟头的位置，才又慢慢的往里插，等到再次抵住花蕊之后，再继续拔出来，又插进去……活塞运动，均匀的进行着。“~嘶~哈~”宋祖儿低头看着肉棒在自己体内进出的样子，小嘴微张的连抽几口凉气，原本白里透红的小脸蛋儿，慢慢变得苍白起来，一双小手也扣再牛奕辰的肩膀上，指甲深深的陷入肉里。随着牛奕辰的的抽插，原本还可以安静看着的宋祖儿，再也忍受不住的叫出声来。被开苞的痛苦，让她娇小的身子一阵巨颤，喉咙里发出一阵哼哼。宋祖儿终于还是忍不住了，用带着颤音的强调说道：“奕辰哥哥……好疼……好像要被撕开了……嗯……好胀……好危险……啊……唔……”但是牛奕辰却并没有改变自己抽送的节奏，就算是有魅魔外挂加身，这也是她的第一次而已，吃点苦头才是正常的。而他那粗大的肉棒，竟然可以插到宋祖儿的体内，本身就已经足够证明魅魔体质的厉害了。“没事的，涓涓乖乖的不要动，马上就会舒服了，比你尿尿的时候还舒服。”在听到宋祖儿的痛叫之后，牛奕辰稳定了一下心神，抽送的频率还是没变，但是右手却腾出来，在她小小的阴蒂上来回抚摸着。这时候想要停下来，真的太困难了，他的肉棒被稚嫩的腔道给紧紧夹住，那种完全包裹，寸步难行的感觉，爽得深入骨髓，叫人终生难忘。“真的吗？”宋祖儿泪眼朦胧，可怜巴巴的问道。“那当然，过一会儿你就会觉得，现在的所有疼痛和忍耐，都是值得的。”“嗯……奕辰哥哥……我相信你……嗯……”小女孩儿这柔弱的模样，愈发激起牛奕辰想要蹂躏她的欲望，但他仍是耐着性子慢慢进出，拨撩着小女孩敏感的阴蒂和小小的乳头，用自己高超的技巧安慰着她。宋祖儿发出一声声轻哼，脸上的表情不断变换着，带着几分英气的眉毛时而紧皱，时而放松，单单看表情就能知道牛奕辰的肉棒进入了什么深度。就算是高潮过后，有了相当充沛的淫液润滑，可是被牛奕辰这堪称凶器的肉棒插入，还是让宋祖儿难受不已，娇嫩的阴埠被肉棒撑开，挤压得变了形状，狭窄莹润的腔道里面，殷红的处女血沿着凄惨的洞口缓缓而下。与之相对，此时的牛奕辰所感受到的，已经全部都是快感了。魅魔幼女的的阴壁好像活物似的，蠕动着将肉棒吞没到里面，每一次抽插，都向外荡漾出阵阵销魂蚀骨的美妙滋味儿。而随着牛奕辰的抽插和撩拨，魅魔的体质渐渐占了上风，宋祖儿的眉头很快便舒展来开，原本苍白的脸蛋儿，也再次恢复了一开始红润可爱的模样。“嗯……嗯……哥哥……嗯……啊……”宋祖儿把抓着牛奕辰肩膀的小手收回来，像是小猫一样，很可爱的收在自己的胸前，发出一声声清脆悦耳，又甜腻动人的吟叫。牛奕辰欣赏着宋祖儿可爱的模样，嘴上问道：“你看，现在是不是就变舒服了？”“嗯……哥哥……好舒服呀……一点都不疼了……哦……”牛奕辰的问话，好像是打开了宋祖儿话语的开关，让她立刻便呻吟出声来，“奕辰哥哥……以前你跟姐姐……是不是就是这种感觉……哎呦……好深呀……啊……要把小肚子给弄破了……哦……啊……”“没错，以前跟你姐姐做爱的时候，就是这种感觉。”牛奕辰看着这样的宋祖儿，心中充满了成就感，一边在她稚嫩的腔道之中大肆抽插，一边捏住她的阴蒂挤压揉捏，“我的小涓涓，有没有后悔呢？”“嗯……咿呀……后悔了……哥哥……我后悔了……啊……以前我就应该跟姐姐一起的……啊……我不喜欢姐姐了……她不让我跟你做……哦……哥哥……太舒服了……我想尿了……又想尿了……哦……啊……”宋祖儿只觉得一阵阵甜美愉悦的感觉，如同潮水一般源源不断的涌上心头，这种她从未感受过的快乐，几乎要蒸发她的理性，让她的小嘴不断的开合，无比诚实的说出了自己内心深处的想法。“啊啊……哥哥……啊……”随着一声甜美娇腻的娇吟，宋祖儿白嫩的如同莲藕一般的小腿紧紧绷直，幼窄粉润的膣壁拼命的吸附、缠绕着牛奕辰的肉棒。紧接着，一股温热的潮水便从阴道最深处溢出，从两人交合的位置一路淌下去，将她的小屁股都给染得亮晶晶的。“~哦~我的好涓涓……”高潮之时，宋祖儿无比紧密的腔道死死的咬着牛奕辰的肉棒。那种前所未有的紧窄，再加上花蕊上像是旋涡一样强烈的吸吮，一瞬间就让牛奕辰精关失守，发出一声低吼之后，就将滚烫的精液尽数喷射在了宋祖儿稚嫩的阴道里面。“啊啊……好深……好爽……哥哥……啊……”被精液冲击着的宋祖儿身体剧烈颤抖着，双脚朝空中胡乱蹬踏了几下，紧接着就好像全身的力气都被抽走了一样，软软的躺在了床上，连根手指都不愿意动弹了。宋祖儿舒服的几乎要晕倒过去，此时被肉棒操弄着进入高潮，和之前被手摸着进入高潮，可是完全不同的。在精液注入体内的一瞬间，宋祖儿感觉仿佛有一股气流从阴道之中涌出，在自己的肚脐下流转一会儿之后，又冲上心脏的位置，然后极有规律的在经络之中来回运转，让她的高潮变得更加绵长，仿佛会一直天长地久的持续下去一样。小女孩儿高潮到失神的表情，让牛奕辰的心中无比满足，而且也有点怕第一次把她弄出什么伤来，便缓慢的将肉棒从她稚嫩的阴道之中拔了出来。‘啵’的一声之后，牛奕辰惊讶的发现，宋祖儿那被撑得一时合不拢的稚嫩腔道口，竟然没有一滴精液流出，仿佛所有的精液都被她的身体给吸收进去了一样。“~嗯~哼~”宋祖儿轻轻摇晃了两下屁股，发出了一声嘤咛。肉棒拔出时带出的一点快感，让她很享受，但是被拔出的空虚，却又让她有些不满。牛奕辰轻轻拍了拍她鼓鼓的小肚子，然后将手指探到她的绵密的阴道里面，最终才确定，她竟然真的将精液给吸收光了。‘这就是魅魔的特点吗？’牛奕辰一时拿不准，在宋祖儿的阴蒂上又轻捏了两下。“啊……奕辰哥哥……”宋祖儿睁开了眼睛，双腿下意识的向中间合了一下之后，又可怜巴巴的看着牛奕辰，“我还想要……”“还想要？”牛奕辰一听，立刻意外的问道：“不觉得疼了吗？”“已经不疼了。”宋祖儿说着，还调整了一下位置，把自己白嫩的小腿又一次向牛奕辰张开了，“奕辰哥哥，你快进来嘛。”粉到近乎无色的阴唇，又向牛奕辰绽放了开来，就这一会儿，她的阴唇竟然又重新并拢了，就跟刚才做爱之前的状态一模一样。不用多说，系统的道具果然是不需要质疑的，说不会受到伤害，就绝对不会受到伤害。“太神奇了！”确定了这一点后，牛奕辰毫不犹豫的一挺腰，将自己粗大的肉棒再次插入了她那无比稚嫩的阴道里面。“啊……哥哥……”宋祖儿再次发出一声尖叫，晶莹的脚趾再次向中间并拢了起来。失而复得喜悦，给宋祖儿的感觉，甚至比一开始的时候更强烈。因为现在的她，已经品尝过性爱的美妙了，不像之前，还是白纸一张，只能任凭牛奕辰摆弄。“好奇怪……好舒服……嗯……哥哥……”宋祖儿痴迷的看着牛奕辰，白嫩的小屁股向上抬了两下，迫不及待的便呼唤着，“哥哥……你动的快点……再快一点……啊……”牛奕辰并没有让她失望，在调整好下体的位置之后，双手抓住宋祖儿洁白的藕臂，坚硬的龟头就像是长枪一样，破开她稚嫩层叠的阴壁，狠狠的顶在小女孩儿柔软又滑嫩的花蕊上。“啪叽……啪叽……啪叽……”在肉与肉之间的激烈摩擦之下，清脆又淫靡的撞击声，第一次在两人之间响了起来。这是性爱无比激烈的象征，这种激烈的性爱出现在宋祖儿这小小的身子上，显得极为禁忌，却又极为刺激，让人欲罢不能。“呀……啊……哥哥……好深……不行……肚肚……肚肚要被捅破了……哦……啊……”在牛奕辰开始驰骋的一刹那，宋祖儿便发出了一声声悦耳动听的吟叫，白嫩的小屁股下意识的摇动着，迎合着对方的侵犯。这动作根本不用人教，仿佛是她天生就会的一样。此时此刻，宋祖儿的双臂变成了牛奕辰手中的缰绳，而跨间赤裸的幼女，就是一匹美丽的小马驹。牛奕辰这高大健壮的骑士，骑起小马来却丝毫不心疼，仍旧是那么快速、那么猛烈……给人的感觉，甚至有些残忍。但是作为小马驹的宋祖儿，却一点也不觉得残忍，她感觉自己的阴道都已经变成了肉棒的形状，柔嫩的子宫颈都被龟头撞得微微凹陷，龟冠的棱角每刮过一丝褶皱，都带给了她无比激烈的快感。这悠长又连续的刺激，让宋祖儿有种神经都快要烧断的错觉。“哥哥……哥哥……啊……快……再快一点……啊……哦……涓涓飞起来了……飞起来了……哦……啊……”随着宋祖儿淫靡的叫声，牛奕辰的呼吸越来越粗重。小女孩儿稚嫩又紧密的阴道，正在无比贪婪的吸吮着他的肉棒，如果他不小心控制的话，只怕一不留神就会被这小妖精给榨出精液来，他一个身经百战的老司机，如果在宋祖儿这么一个小幼女的身上翻车，可就成了笑话了。`;

// VÍ DỤ 2 (Văn bản dài để kiểm tra Gemini AI):
// var testText = `
// 楚晚宁是真的狗。
// 他吸了一口，那浓精几乎是立刻就烫得他皱起了眉头。
// `;

// 2. Nhập mã ngôn ngữ nguồn (ví dụ: 'zh' cho tiếng Trung)
var testFrom = 'zh';

// 3. Nhập mã của prompt đích bạn muốn dùng (ID từ file language_list.js)
// Ví dụ: 'vi', 'vi_sac', 'vi_NameEng', 'vi_vietlai', 'en'
var testTo = 'vi_sac';

// =======================================================================
// --- KẾT THÚC KHU VỰC CẤU HÌNH ---
// --- Không cần chỉnh sửa code bên dưới ---
// =======================================================================

var currentKeyIndex = 0;

// --- LOGIC CỦA GEMINI AI (Không thay đổi) ---
function callGeminiAPI(text, prompt, apiKey) {
    if (!apiKey) { return { status: "error", message: "API Key không hợp lệ." }; }
    if (!text || text.trim() === '') { return { status: "success", data: "" }; }
    var full_prompt = prompt + "\n\n---\n\n" + text;
    var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" + apiKey;
    var body = {
        "contents": [{ "parts": [{ "text": full_prompt }] }],
        "generationConfig": { "temperature": 0.75, "topP": 0.95, "maxOutputTokens": 65536 },
        "safetySettings": [ { "category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE" }, { "category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE" }, { "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE" }, { "category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE" } ]
    };
    try {
        var response = fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        if (response.ok) {
            var result = JSON.parse(response.text());
            if (result.candidates && result.candidates.length > 0 && result.candidates[0].content) { return { status: "success", data: result.candidates[0].content.parts[0].text.trim() }; }
            if (result.promptFeedback && result.promptFeedback.blockReason) { return { status: "blocked", message: "Bị chặn bởi Safety Settings: " + result.promptFeedback.blockReason };}
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + response.text() };
        } else {
            return { status: "key_error", message: "Lỗi HTTP " + response.status + " (API key có thể sai hoặc hết hạn mức)." };
        }
    } catch (e) {
        return { status: "error", message: "Ngoại lệ Javascript: " + e.toString() };
    }
}
function translateInChunksByLine(text, prompt) {
    var lines = text.split('\n'); var translatedLines = []; var errorOccurred = false;
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i]; if (line.trim() === '') { translatedLines.push(''); continue; }
        var lineTranslated = false;
        for (var j = 0; j < apiKeys.length; j++) {
            var key = apiKeys[currentKeyIndex]; var result = callGeminiAPI(line, prompt, key);
            if (result.status === "success") { translatedLines.push(result.data); lineTranslated = true; break; }
            if (result.status === "blocked") { translatedLines.push("..."); lineTranslated = true; break; }
            if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
            else { translatedLines.push("[LỖI DỊCH DÒNG: " + result.message + "]"); lineTranslated = true; errorOccurred = true; break; }
        }
        if (!lineTranslated) { translatedLines.push("[LỖI: TẤT CẢ API KEY ĐỀU KHÔNG HOẠT ĐỘNG]"); errorOccurred = true; }
    }
    if (errorOccurred) { return { status: "partial_error", data: translatedLines.join('\n') }; }
    return { status: "success", data: translatedLines.join('\n') };
}
function translateSingleChunk(chunkText, prompt, isPinyinRoute) {
    for (var i = 0; i < apiKeys.length; i++) {
        var key = apiKeys[currentKeyIndex]; var result = callGeminiAPI(chunkText, prompt, key);
        if (result.status === "success") { return result; }
        if (result.status === "blocked") {
            if (isPinyinRoute) { return result; } 
            else { return translateInChunksByLine(chunkText, prompt); }
        }
        if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
        else { return result; }
    }
    return { status: "error", message: "Tất cả các API key đều không hoạt động." };
}

// --- HÀM THỰC THI CHÍNH (SỬ DỤNG DỮ LIỆU TEST) ---
function execute(text, from, to) {
    // ---- GHI ĐÈ DỮ LIỆU TỪ ỨNG DỤNG BẰNG DỮ LIỆU THỬ NGHIỆM ----
    text = testText;
    from = testFrom;
    to = testTo;
    console.log("!!! CHẾ ĐỘ THỬ NGHIỆM ĐANG BẬT !!! Đang sử dụng dữ liệu được khai báo trong file.");
    // -----------------------------------------------------------

    if (!text || text.trim() === '') { return Response.success("?"); }

    if (text.length < 200) {
        console.log("Phát hiện văn bản ngắn (< 200 ký tự). Sử dụng Baidu Translate.");
        var baiduToLang = to;
        if (to === 'vi_sac' || to === 'vi_vietlai' || to === 'vi_NameEng') {
            baiduToLang = 'vi';
        }
        console.log("Mã ngôn ngữ đích '" + to + "' được chuyển thành '" + baiduToLang + "' cho Baidu.");
        
        var rawTranslatedText = baiduTranslateContent(text, from, baiduToLang, 0); 
        if (rawTranslatedText !== null) {
            // Áp dụng logic định dạng hiển thị cho kết quả của Baidu
            var lines = rawTranslatedText.split('\n');
            var finalOutput = "";
            for (var i = 0; i < lines.length; i++) {
                finalOutput += lines[i] + "\n";
            }
            return Response.success(finalOutput.trim());
        } else {
            return Response.error("Lỗi khi dịch bằng Baidu Translate (sau nhiều lần thử lại).");
        }
    }
    
    console.log("Văn bản dài. Sử dụng quy trình Gemini AI.");
    if (!apiKeys || apiKeys.length === 0 || (apiKeys[0].indexOf("YOUR_GEMINI_API_KEY") !== -1)) {
        return Response.error("Vui lòng cấu hình API key trong file apikey.js.");
    }
    var selectedPrompt = prompts[to] || prompts["vi"];
    var processedText;
    var isPinyinRoute = false;
    if (to === 'vi' || to === 'vi_sac' || to === 'vi_NameEng') {
        isPinyinRoute = true;
        try { load("phienam.js"); processedText = phienAmToHanViet(text); } 
        catch (e) { return Response.error("LỖI: Không thể tải file phienam.js."); }
    } else {
        isPinyinRoute = false;
        processedText = text;
    }
    var textChunks = [];
    var CHUNK_SIZE = 5000;
    var MIN_LAST_CHUNK_SIZE = 1000;
    if (processedText.length > CHUNK_SIZE) {
        var tempChunks = [];
        for (var i = 0; i < processedText.length; i += CHUNK_SIZE) { tempChunks.push(processedText.substring(i, i + CHUNK_SIZE)); }
        if (tempChunks.length > 1 && tempChunks[tempChunks.length - 1].length < MIN_LAST_CHUNK_SIZE) {
            var lastChunk = tempChunks.pop();
            var secondLastChunk = tempChunks.pop();
            tempChunks.push(secondLastChunk + lastChunk);
        }
        textChunks = tempChunks;
    } else {
        textChunks.push(processedText);
    }
    var finalParts = [];
    for (var k = 0; k < textChunks.length; k++) {
        var chunkResult = translateSingleChunk(textChunks[k], selectedPrompt, isPinyinRoute);
        if (chunkResult.status === 'success' || chunkResult.status === 'partial_error') {
            finalParts.push(chunkResult.data);
        } else {
            var errorString = "\n\n<<<<<--- LỖI DỊCH PHẦN " + (k + 1) + " --->>>>>\n" +
                              "Lý do: " + chunkResult.message + "\n" +
                              "<<<<<--- KẾT THÚC LỖI --->>>>>\n\n";
            finalParts.push(errorString);
        }
    }
    
    var finalContent = finalParts.join('\n\n');
    var lines = finalContent.split('\n');
    var finalOutput = "";
    for (var i = 0; i < lines.length; i++) {
        finalOutput += lines[i] + "\n";
    }
    return Response.success(finalOutput.trim());
}