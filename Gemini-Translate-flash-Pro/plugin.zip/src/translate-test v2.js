// translate_test.js (Phiên bản Thử nghiệm Hybrid Baidu + Gemini)
load("language_list.js"); 
load("apikey.js");
load("prompt.js");
load("baidutranslate.js"); // Tải logic của Baidu Translate

// =======================================================================
// --- KHU VỰC CẤU HÌNH THỬ NGHIỆM ---
// --- Chỉ cần thay đổi nội dung trong 3 biến dưới đây để thử nghiệm ---
// =======================================================================

// 1. Dán văn bản bạn muốn thử nghiệm vào giữa hai dấu ` `
// VÍ DỤ 1 (Văn bản ngắn để kiểm tra Baidu Translate):
// var testText = `第一章 楔子`;
// VÍ DỤ 2 (Văn bản dài để kiểm tra Gemini AI):
var testText = `
第一卷 第1章 荒唐梦境
“辰儿。”一声甜美的呼唤让叶辰缓缓睁开眼睛，却发现自己此时正躺在一个女人的怀里。
对于这个怀抱，叶辰可以说是熟悉之极了，可是今天却和以往有很大的不同，因为此时抱着他的女人竟然是一丝不挂的，而他自己，也同样的不着寸缕，这在以前，是绝对没有过的。
心中的惊疑让叶辰下意识得向抱着自己的女人看去：美的令人眩目的脸庞、晶莹如玉的肌肤、硕大而丰挺的玉乳奶子、纤细的柳腰、丰盈如满月的肥臀、笔直修长而又圆润的美腿，这一切的一切，无不向人诠释着一个词——完美！
即使是还不怎么懂得欣赏女人，即使明知道以自己和她的关系不应该有这样的想法，但是叶辰还是忍不住在脑海里浮现出了一句话：眼前的美人，有着绝对可以让任何男人疯狂的完美。
“想什么呢？”熟悉的甜美声音再次传来，打断了叶辰的逸想，面对着美人一如既往的温柔笑容，叶辰不由的心虚起来，不过还没等他心里的羞愧蔓延开来，便被下体的一阵舒爽打断了。
直到此时，他才发现，自己下面的那根鸡巴正被美人的玉手轻轻握着，而且一下一下得撸动着，而那根以往自己只是用来尿尿的东西此刻也变得坚硬无比。
没等叶辰开口，美人又是展颜一笑：“辰儿，是不是想女人了？”
“没，没有。”叶辰结结巴巴得否认道。
“还说没有，鸡巴都硬成这样了。”美人轻笑着紧了紧小手，握得叶辰又是一阵舒爽。
还不是你给弄硬的！
叶辰心里嘀咕着，却没有说出口，同时心中还很是惊讶，他怎么也没有想到，“鸡巴”这个词竟然会从美人的嘴里说出来，平时他只是在同学们骂人的时候听到过这个词语，知道它绝对是一个很粗鄙的称呼，可是不知道为什么，这个粗鄙之极的词语从圣洁无比的她嘴里说出来，不但没有让自己感觉突兀，反而从心底产生了一种说不出的刺激感。
虽然叶辰已经是面红耳赤，但是美人却仍没有放过他，继续笑道：“没关系的，男孩子到了你这个年龄，想女人是很正常的事，来，不要怕，试试女人的感觉吧。”说着，拉过叶辰的手按在了自己的胸膛奶子之上。
好软，好滑！
叶辰下意识得抓住那一团绵软，心中暗暗赞叹着，同时还不由为它的巨大而惊叹，自己的手掌已经算是不小了，此时张开五指，竟然无法将它完全罩住。
一边在心里赞叹着，叶辰下意识的把玩起手里的那团美妙来，很快，他便感觉到，那团绵软顶端的乳头渐渐硬了起来，而美人也从喉咙里发出了一连串娇媚的轻吟。
慢慢的，叶辰不再满足于只是用手揉捏，忍不住弯起了身子，将脑袋凑到了美人的胸前，张开嘴巴轻轻含住那颗已经充血的小奶头，一下一下得舔弄吮吸起来。
也许是被叶辰弄痒了，美人发出了一串银铃般的格格娇笑，那是一种叶辰从未听过的笑声，一反平日里的温柔平和，充满了诱惑与……淫荡。
不错，就是淫荡，虽然叶辰的心里万分不想承认，但是这个词语却根本不受控制得映入了他的脑海，那淫荡的笑声让他不由的停止了吮吸，抬起头来看向怀中的美人，却见她正美目轻闭，倾国倾城的绝世娇颜之上布满了自己从未见过的异样红晕，小嘴微微张开，在轻声浪吟的同时还不时得伸出香舌轻舐着诱人的红唇，那表情，比她的声音更加的淫荡。
也不知是因为惊奇，还是不敢想象这样一副淫荡的表情会出现在她的脸上，叶辰呆呆得看着她，心里的那股无名之火越烧越旺。
忽然，美人睁开了眼睛，秋水般的眸子直接和叶辰对上，使得他心头一震，忙想把自己的目光移开，不料美人不但没有怪他如此看着自己，反而很是满足的样子，娇笑着说道：“看来我们辰儿真的长大了，知道欣赏女人了，来，给你看些更好的！”
说着，美人推着叶辰坐了起来，自己则是仰面躺着，慢慢将修长的美腿大大分开，把自己最隐私的部位展露在叶辰的眼前。
此时的叶辰已经无法做出思考了，只是呆呆得看着美人的动作，最后终于把目光定格在了那最美妙的部位上。
美人的私处异常的饱满，而且很是白嫩，最重要的是，上面竟然没有半根毛发，简直就像一个刚出锅的白馒头，而这个诱人的馒头嫩屄中间，裂开了一条粉红色的缝隙，里面的嫩肉若隐若现，显得娇艳欲滴。
美人将玉手伸到自己胯下，用手指按住两片白嫩的大阴唇，轻轻向两边分开，娇笑着问道：“好看吗？”
“好……好看！”叶辰用力咽了口口水，呆呆得回答着，双眼却片刻也不舍得离开那美妙的地方，随着美人的玉手轻分，那条小小的缝隙骤然变大，露出了里面粉红色的娇媚，上面还沾着几滴晶莹的春露，是那么的诱人，让叶辰恨不得将它含进嘴里，好好的品尝一番。
“那摸摸看啊。”美人笑着继续诱惑叶辰。
叶辰又吞下一口口水，强忍着心头的激动，伸出右手的食指，慢慢向那个最诱人的地方探去，可是在快要碰到那里的时候，却又停了下来，因为那里实在是太过娇嫩，让他觉得自己只要轻轻一碰，就会弄破了它。
而在这个时候，美人的纤腰却是轻轻一挺，主动将那美妙的裂缝凑了上来，碰到了叶辰的手指，叶辰心中先是一惊，随即发现那美妙并没有被自己碰破，于是放下心来，轻柔得在那美妙的裂缝里抚摸起来。
嫩、滑、软……一瞬间，无数的词语涌入叶辰的脑中，却又总是不能形容自己手指所触的感觉，总之，那手感绝对是美到了极点，让他忍不住加大了抚摸的力度，手指来回得在那湿滑的嫩屄中划动着，甚至还无师自通得不住撩拨缝隙顶端那颗小小的凸起。
在叶辰的抚摸下，美人性感的娇躯不住得颤抖着，嘴里更是发出了比刚才更加销魂的娇吟，原本大大分开的双腿再也无法自持，猛得收缩回来，紧紧夹住了叶辰的大手。
虽然美人诱人双腿的紧夹并不影响叶辰抚摸的动作，但是他又岂肯让那般美妙的场景消失在自己眼前？
于是叶辰放弃了所有的顾忌，用双手按住美人夹在一起的双腿，再次将它们分开，而为了能再次摸到那美妙的地方，他不得不伏下身去，用双臂压着美人的玉腿，解放出来的双手一只像美人刚才那样轻轻掰开两片粉嫩阴唇，另一只手则继续起了刚才的动作。
“呃……啊……”美人的浪吟声越来越大，随着叶辰的抚摸，丰盈的肥臀一下又一下得向上挺动，显得激动异常，而那道嫩滑的缝隙里，也变得越来越湿了。
经过这一会的观察，叶辰已经发现，美人下面的裂缝中，除了那一颗小小的凸起以外，还有着一大一小两个小洞，而那越来越多的春露都是从下面那个略大一些的小洞里流出来的。
也不知是突然福至心灵，还是出于男人的本能，叶辰很是敏锐得找到了让美人更舒服的办法，在美人裂缝中徘徊的食指来到下面的洞穴后并没有再次离开，而是轻轻往里面按去，借着那春露的润滑，很容易就塞进去一个指节。
突如其来的动作弄得美人娇躯又是一阵颤抖，跟着叶辰发现，那本能十分紧凑的洞穴忽然一下收得更紧，死死得咬住自己插进去的手指，弄得他别说是继续向里面插了，就连拔出来都有些困难。
既然无法继续深入，叶辰也没有强求，转而轻轻活动起了手指，在美人紧小的洞穴里抠弄起来，直把她弄得呼吸越来越急促，浪吟声也越来越大。
随着时间的推移，美人屄穴里涌出的水越来越多，而叶辰也发现，那小小的屄穴已经不再像刚才那么紧了，于是心中又生出了探索的欲望，手指微微用力，准备继续深入。
不料正在享受的美人突然反应了过来，伸手阻止了他，娇嗔道：“不可以把手指插进去！”
叶辰不由一愣，他怎么也没想到，一直配合，甚至可以说是主动的美人会阻止他，心里忍不住有些失望。
美人显然是注意到了他的表情，好气又好笑的道：“傻孩子，不让你用手指插，又没说不让用别的。”
“什么啊？”叶辰傻傻的问道。
“小笨蛋，当然是它了。”美人指了指他那根一直没有半丝发软迹象的东西。
“可以吗？”叶辰不禁有些凌乱了，看了看那美妙到极点的娇唇肉屄，又看了一眼自己已经颇具规模的东西，这东西可比手指粗了好几倍的，真的能插进去？
看到叶辰这样，美人显然是有些急了，一把将他推倒在床上，自己则是站了起来，分开修长白嫩的美腿跨骑在他的身上，慢慢得蹲坐下来，伸手握住他那根笔直朝天的大鸡巴，顶在自己湿润无比的地方。
粗糙的龟头和娇嫩的美屄甫一接触，二人都不由暗吸了一口气，虽然还没有插入，但只是碰触到的感觉，就已经让二人舒爽不已了。
美人轻咬了下嘴唇，暂时停止了动作，拉过叶辰的双手，让他握住自己胸前那对即使直立了身子，仍丝毫不见下垂的玉乳，然后又把双手伸到胯下，一手握着叶辰的鸡巴，一手分开自己的阴唇，用龟头在那湿润的裂缝里一下一下得摩擦，同时伏下身来，用柔软的双唇封住了叶辰的嘴巴。
好舒服！
叶辰心里大叫着，用心得体会接吻的乐趣和龟头摩擦美人妙处的快感，同时双手也不住得活动着，弄得美人那两团凝脂般的晶莹不断的变幻着各种形状。
也许是实在痒的受不了了，美人终于停止了摩擦，将龟头顶在自己的洞穴上，然后用力一坐，随着一声轻微的水响，叶辰那根已经粗壮坚挺的大鸡巴一下尽根没入了美人紧小粉嫩的屄道里。
“哦……”巨大的快感让二人同时发出了一声轻吟，叶辰只觉得自己似乎是一下飞上了天，鸡巴被妙肉紧紧包夹而产生的强烈到极点的快感，似乎比他以前十几前所遇到的舒服的感觉加一起都要多。
在这样巨大的快感之中，叶辰很不争气得浑身一颤，积压了十几年的童子之精竟然就这么喷薄而出了。
初尝肏屄滋味的美妙，叶辰忍不住紧紧闭上眼睛，用心得体会这一刻的感受，直到彻底停止了喷射。
只是此刻，他依然处于春梦和意识清醒人未醒的状态中。他却不知道，在那一层单薄的被单下，却发生着奇异的变化！
挂在他脖子上的莲花玉牌项链，此刻正微微闪烁着粉红、乳白相间的光芒！
粉白莲花玉牌是叶辰的爸爸叶耀阳出席一场慈善拍卖的时候，一位神秘的老道士让他拍下来的，因为小巧精致，加上材质奇特、乳白色的玉色带着粉红色的纹路，最奇特的是，那小小的玉牌中竟然有一朵乳白莲花，也不知道是真是假。
就是因为太过奇特，感觉颇为有缘，所以被叶耀阳拍来送给了妻子洛雪，后来洛雪又将其送给儿子作为满周岁岁的生日礼物，也正是这个玉牌无声无息的陪伴了叶辰十多年的时光。
只是，就连叶耀阳也没有想到，这个精巧奇特的玉牌却彻底的改变了他的儿子和他一家人的一生。
之前多次的梦遗射精都未发生什么，而最为诡异的是，这次他梦遗所喷射出的精液过多不小心射到莲花玉牌上的时候，却被它诡异的吸收了！
叶辰其实在快要射精的时候早已经清醒了，或者说他的意识早就醒来了，只不过让他惊恐的是，他的意识好似被封存了一般，困在体内根本无法真正的醒来，这种未知的神秘情况让他手足无措，想叫都叫不出来，暗无天日的精神世界，却只能看到遥远的地方闪烁着红白光芒，而他却只能继续做着春梦，继续鸡巴射精，竟然是意外的梦中梦！
这粉白交替的光芒正是挂在叶辰胸前的莲花玉牌。
吸收了足够的精液，莲花玉牌产生了惊人的变化，凝固的玉牌竟然好似融化了一般，乳玉和那粉红色的纹路逐渐的融化成了水流一般，而玉牌中，一朵乳白的莲花慢慢呈现，华美神秘、高贵圣洁的莲花通体玉白，只有那莲花玉台中心，有一点鲜艳的粉红，就好似一颗美人痣一般。
若是细眼看去，定可以看出那是一道穿着红色衣裙的女人的倩影，而那女人是那样的绝美、那样的熟悉……
玉莲虽小，却密密麻麻的开着数之不尽的花瓣，在乳玉白莲完全呈现的那一刻，莲花玉牌彻底的一份为二。
水流一般的乳玉夹带着粉红纹路好似渗透一般融入了叶辰的身体，而那圣洁华贵的莲花更是一闪没入了他的胸口。
如果此刻能够透析叶辰的身体，一定会发现惊人的变化，一分为二的莲花玉牌一上一下分别进入了叶辰的脑海和丹田！
脑海中，一朵乳白玉莲散发着柔和圣洁的光芒，顺时针旋转漂浮在叶辰的识海，丹田内，乳白液体融合着粉红纹路，凝聚成了一颗核桃大小的珠子，悬浮在丹田内，时刻散发着逼人的光芒，光芒不断融合叶辰的身体，好似养分一般，被叶辰的身子贪婪的吸收着！
这种诡异的变化让叶辰心中无比的惊恐，然而，很快他便惊奇的感觉到自己的身体无时无刻都在发生着变化！
最明显的是，丹田内散发出来的能量融合了身体之后，让他的身体好似即将烧开的热水一般，轻微而又平和的沸腾着，酥酥麻麻的感觉，身体在一点一点的改变，肉眼可见的是，身体似乎慢慢变得壮实，胸部和腹部开始勾勒出线条，竟然有了明显的肌肉曲线！
“这是怎么回事？我不是还没有醒来吗？竟然能够看到身体的情况？难道是……”
叶辰的意识中呈现着那乳白莲花和丹田内的珠子，一时间，心中翻起了惊涛骇浪！
虽然弄不明白这些东西到底是什么？可是叶辰能够感受到它们的神奇，而且，他隐隐约约的觉得，自己或许得到了天大的奇遇！
心中很不平静的叶辰没有发现，在那莲花玉牌融合完成之后，他那一直被封存的意识已经脱困了出来。
不知道什么时候，他已经能够睁开了眼睛！
入目的，却是卧室里那熟悉的天花板，刚才的一切，不过是南柯一梦。
慢慢得坐了起来，叶辰没有理会内裤里那粘粘的感觉，双手插进头发里，用力把头埋在了膝盖上，嘴里发出了一声痛苦的呻吟。
虽然从未有过这样的经历，但是早已熟读十八禁和日本众多AV女老师的大片的他哪里能不明白，自己刚刚做了春梦了，当然，这并不是他痛苦的根源，毕竟他已经十六岁，做春梦自然是很正常的事，甚至到现在他都没有真正的和女人发生性关系，对于他的身份家世来说可能有点不可思议。
真正令他痛苦的，却是出现在他梦中的那个女人，他实在无法理解，为什么自己幻想的性爱对象会是她，虽然十几年来一直霸占着“帝都第一美人”称号的她足以让所有的男人产生幻想，叶辰也曾经多番与其有着肢体上暧昧的接触，但是叶辰心里清楚，这世上无论是谁跟她发生性关系都行，唯独自己不行！
“为什么会这样？她那么美，为什么是我的妈妈……”叶辰痛苦的呻吟着，可是梦中的场景却仿佛电影一般一遍又一遍的在他的脑海里重复，这无异会让他更加的苦恼。
不，我不会将她让给别人的，她的美只为我绽放！
这一刻，清醒过来的叶辰因为受到了‘银灵诀’的影响，似乎心中下了某种决定……
`;

// 2. Nhập mã ngôn ngữ nguồn (ví dụ: 'zh' cho tiếng Trung)
var testFrom = 'zh';

// 3. Nhập mã của prompt đích bạn muốn dùng (ID từ file language_list.js)
// Ví dụ: 'vi', 'vi_sac', 'vi_NameEng', 'vi_vietlai', 'en'
var testTo = 'vi_sac';

// =======================================================================
// --- KẾT THÚC KHU VỰC CẤU HÌNH ---
// --- Không cần chỉnh sửa code bên dưới ---
// =======================================================================


var currentKeyIndex = 0;

// --- LOGIC CỦA GEMINI AI (Không thay đổi) ---
function callGeminiAPI(text, prompt, apiKey) {
    if (!apiKey) { return { status: "error", message: "API Key không hợp lệ." }; }
    if (!text || text.trim() === '') { return { status: "success", data: "" }; }
    var full_prompt = prompt + "\n\n---\n\n" + text;
    var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" + apiKey;
    var body = {
        "contents": [{ "parts": [{ "text": full_prompt }] }],
        "generationConfig": { "temperature": 0.75, "topP": 0.95, "maxOutputTokens": 65536 },
        "safetySettings": [ { "category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE" }, { "category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE" }, { "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE" }, { "category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE" } ]
    };
    try {
        var response = fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        if (response.ok) {
            var result = JSON.parse(response.text());
            if (result.candidates && result.candidates.length > 0 && result.candidates[0].content) {
                return { status: "success", data: result.candidates[0].content.parts[0].text.trim() };
            }
            if (result.promptFeedback && result.promptFeedback.blockReason) {
                return { status: "blocked", message: "Bị chặn bởi Safety Settings: " + result.promptFeedback.blockReason };
            }
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + response.text() };
        } else {
            return { status: "key_error", message: "Lỗi HTTP " + response.status + " (API key có thể sai hoặc hết hạn mức)." };
        }
    } catch (e) {
        return { status: "error", message: "Ngoại lệ Javascript: " + e.toString() };
    }
}

function translateInChunksByLine(text, prompt) {
    var lines = text.split('\n');
    var translatedLines = [];
    var errorOccurred = false;
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.trim() === '') { translatedLines.push(''); continue; }
        var lineTranslated = false;
        for (var j = 0; j < apiKeys.length; j++) {
            var key = apiKeys[currentKeyIndex];
            var result = callGeminiAPI(line, prompt, key);
            if (result.status === "success") { translatedLines.push(result.data); lineTranslated = true; break; }
            if (result.status === "blocked") { translatedLines.push("..."); lineTranslated = true; break; }
            if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
            else { translatedLines.push("[LỖI DỊCH DÒNG: " + result.message + "]"); lineTranslated = true; errorOccurred = true; break; }
        }
        if (!lineTranslated) { translatedLines.push("[LỖI: TẤT CẢ API KEY ĐỀU KHÔNG HOẠT ĐỘNG]"); errorOccurred = true; }
    }
    if (errorOccurred) { return { status: "partial_error", data: translatedLines.join('\n') }; }
    return { status: "success", data: translatedLines.join('\n') };
}

function translateSingleChunk(chunkText, prompt, isPinyinRoute) {
    for (var i = 0; i < apiKeys.length; i++) {
        var key = apiKeys[currentKeyIndex];
        var result = callGeminiAPI(chunkText, prompt, key);
        if (result.status === "success") { return result; }
        if (result.status === "blocked") {
            if (isPinyinRoute) { return result; } 
            else { return translateInChunksByLine(chunkText, prompt); }
        }
        if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
        else { return result; }
    }
    return { status: "error", message: "Tất cả các API key đều không hoạt động." };
}

// --- HÀM THỰC THI CHÍNH (SỬ DỤNG DỮ LIỆU TEST) ---
function execute(text, from, to) {
    // ---- GHI ĐÈ DỮ LIỆU TỪ ỨNG DỤNG BẰNG DỮ LIỆU THỬ NGHIỆM ----
    text = testText;
    from = testFrom;
    to = testTo;
    console.log("!!! CHẾ ĐỘ THỬ NGHIỆM ĐANG BẬT !!! Đang sử dụng dữ liệu được khai báo trong file.");
    // -----------------------------------------------------------

    if (!text || text.trim() === '') { return Response.success("?"); }

    if (text.length < 200) {
        console.log("Phát hiện văn bản ngắn (< 200 ký tự). Sử dụng Baidu Translate.");
        var baiduToLang = to;
        if (to === 'vi_sac' || to === 'vi_vietlai' || to === 'vi_NameEng') {
            baiduToLang = 'vi';
        }
        console.log("Mã ngôn ngữ đích '" + to + "' được chuyển thành '" + baiduToLang + "' cho Baidu.");
        var baiduResult = baiduTranslateContent(text, from, baiduToLang, 0); 
        if (baiduResult) { return baiduResult; } 
        else { return Response.error("Lỗi khi dịch bằng Baidu Translate."); }
    }
    
    console.log("Văn bản dài. Sử dụng quy trình Gemini AI.");
    if (!apiKeys || apiKeys.length === 0 || (apiKeys[0].indexOf("YOUR_GEMINI_API_KEY") !== -1)) {
        return Response.error("Vui lòng cấu hình API key trong file apikey.js.");
    }

    var selectedPrompt = prompts[to] || prompts["vi"];
    var processedText;
    var isPinyinRoute = false;

    if (to === 'vi' || to === 'vi_sac' || to === 'vi_NameEng') {
        isPinyinRoute = true;
        try { load("phienam.js"); processedText = phienAmToHanViet(text); } 
        catch (e) { return Response.error("LỖI: Không thể tải file phienam.js."); }
    } else {
        isPinyinRoute = false;
        processedText = text;
    }

    var textChunks = [];
    var CHUNK_SIZE = 5000;
    var MIN_LAST_CHUNK_SIZE = 1000;
    
    if (processedText.length > CHUNK_SIZE) {
        var tempChunks = [];
        for (var i = 0; i < processedText.length; i += CHUNK_SIZE) { tempChunks.push(processedText.substring(i, i + CHUNK_SIZE)); }
        if (tempChunks.length > 1 && tempChunks[tempChunks.length - 1].length < MIN_LAST_CHUNK_SIZE) {
            var lastChunk = tempChunks.pop();
            var secondLastChunk = tempChunks.pop();
            tempChunks.push(secondLastChunk + lastChunk);
        }
        textChunks = tempChunks;
    } else {
        textChunks.push(processedText);
    }

    var finalParts = [];
    for (var k = 0; k < textChunks.length; k++) {
        var chunkResult = translateSingleChunk(textChunks[k], selectedPrompt, isPinyinRoute);
        if (chunkResult.status === 'success' || chunkResult.status === 'partial_error') {
            finalParts.push(chunkResult.data);
        } else {
            var errorString = "\n\n<<<<<--- LỖI DỊCH PHẦN " + (k + 1) + " --->>>>>\n" +
                              "Lý do: " + chunkResult.message + "\n" +
                              "<<<<<--- KẾT THÚC LỖI --->>>>>\n\n";
            finalParts.push(errorString);
        }
    }
    
    var finalContent = finalParts.join('\n\n');
    var lines = finalContent.split('\n');
    var finalOutput = "";
    for (var i = 0; i < lines.length; i++) {
        finalOutput += lines[i] + "\n";
    }

    return Response.success(finalOutput.trim());
}