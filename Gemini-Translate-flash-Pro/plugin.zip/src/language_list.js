let languages = [
    {"id": "zh", "name": "Trung"},
    {"id": "en", "name": "Anh"},
    {"id": "vi", "name": "Việt (Tiêu chuẩn)"},
    {"id": "ja", "name": "Nhật"},
    {"id": "ko", "name": "Hàn"},
    {"id": "vi_sac", "name": "Việt (Truyện Sắc)"},
    {"id": "vi_huyenhuyen", "name": "Việt (Huyền Huyễn)"},
    {"id": "vi_tienhiep", "name": "Việt (Tiên Hiệp)"},
    {"id": "vi_vietlai", "name": "Việt (Viết Lại Convert)"}
];