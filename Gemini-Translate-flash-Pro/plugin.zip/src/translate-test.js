load("language_list.js"); 
load("apikey.js");
load("prompt.js");

// =======================================================================
// --- KHU VỰC CẤU HÌNH THỬ NGHIỆM ---
// --- Chỉ cần thay đổi nội dung trong 3 biến dưới đây để thử nghiệm ---
// =======================================================================

// 1. Dán văn bản chữ Hán bạn muốn thử nghiệm vào giữa hai dấu ` `
var testText = `
Chương_693-_Ngang_tiêu!
 第六百九十三章昂霄! 
冥府,不可言述之地.
陡然间,原本入定中(昂霄)睁开双眼,倒抽了一口冷气,随后下意识地朝着现世方向遥遥看去.
又有人想要害我?
‘不太对. 这次竟能让我都生出几分心惊肉跳的感觉,鸿运?那幕后之人这么快就又要对我出手?’
什么仇什么怨?
想到这里,(昂霄)更加怀疑那个所谓的幕后之人其实就是鸿运,毕竟也就鸿运和他有这么大仇.
而且问题在于鸿运究竟准备了什么手段,居然能真正让他生出危机感,这可不像是金丹初期能办到的事情,可见鸿运谋划应当切实命中了他的要害,可自己那么多后手,他到底掌握了多少?
总不可能全掌握了吧.
这个念头一出现,(昂霄)自己都觉得荒诞不经,忍不住笑出了声. 然而渐渐的,他的笑声变低了.
真的不可能吗?
‘此前在海外受挫,我还可以理解,毕竟碧阳修真界当年鸿运也去过,能布下那一局算是情理之中.’
可其他的呢?
‘索唤,(龙蛇盘影菩萨),还有我(报世法外身),这三个后手,至少后两者鸿运不可能知道的.’
(昂霄)坐直了身子,开始认真思索起来:‘既然如此那就只有索唤了,毕竟索唤在海外,鸿运也去过海外,不是没有可能. 无论如何,当料敌从宽,先假定鸿运掌握了索唤情报再说.’
一念至此,(昂霄)当即掐定法诀.
他需要验证一番.
几乎同时,海外,地火海心炉中,刚刚吞并了原身因果索唤猛然抬头,朝着身旁的吕阳看了过去:
‘有人来了.’
吕阳闻言先是一愣,随后大为吃惊:
‘谁?(昂霄)!?’
这一刻,他都不得不(昂霄)警惕性,自己这边才刚下完手,(昂霄)居然已经察觉到不对劲了?
‘稳住他.’
吕阳示意了一下,随后便主动淡去身形,而索唤则是收敛气机,甚至干脆将洞天藏进正道旗,彻底隔离出来,将自身位格拉低到筑基后期,然后才将(灵墟福地)持在了手中默默运化.
很快,(灵墟福地)内.
(昂霄)意识悄无声息降临,静静地打量起了索唤没有犹豫,一道知见障二话不说就套了上去.
紧接着,他又看了看四周.
‘没有异样,一切正常.’
仿佛之前只是他多疑的性格发作,想多了. 可越是如此,(昂霄)心中的烦闷焦躁就越是难以抚平.
‘还是不对!’
(昂霄)轻揉眉心,他对自己灵觉极为自信,空穴来风,必有缘由,事情肯定有什么地方出错了.
这一刻,他展示出圣宗真君作风.
抛开事实不谈.
不管有没有异常,我先下结论!我认定是索唤这边出了问题,而索唤没有异常,说明问题非常严重!
‘(长流水). 可能要放弃了!’
(昂霄)心中沉重,索唤这步棋是他谋夺(长流水)关键,如今却可能被废了,他心情自然不好.
隐约间,他已然察觉到了危机.
‘(长流水)被废那(覆灯火)呢?如果真的是鸿运在布局,(覆灯火)恐怕也要生出诸多变数.’
‘要不. 提前发动,先抢(白蜡金)和(砂中土)?’
‘如此一来,至少不会让我跌落境界.’
不知不觉间,(昂霄)思绪已经和上一世他重合,都是惊觉危机,打算用闪电战获得一个保底.
当断不断,反受其乱.
下一秒,(昂霄)就已经抽离意识,转而来到江西净土,迅速和(龙蛇盘影菩萨)勾连在了一起.
然而这一世和上一世不同了.
上一世,吕阳对(龙蛇盘影菩萨)后手一无所知,这才叫(昂霄)得逞,这一世他却得知了这招.
不仅知道,还借元屠之手把消息传递给了净土!
结果就是当(昂霄)将意识投入净土之后,惊恐地发现(龙蛇盘影菩萨)不知何时竟被囚禁起来!
‘暴露了!’
霎时间,哪怕以(昂霄)道心,此刻也不禁生出了如坠冰窟般的寒冷,下意识地生出了一个念头:
‘哪个道主要害我!?’
是的,道主!
能够提前洞悉自己最大的后手,除了道主还有可能是谁?难道是世尊吗?没错,世尊最有这个可能!
毕竟世尊向来是有口皆碑.
自己的行为本就是在世尊容忍度上左右横跳,而世尊没有忍住亲自下场炸鱼的可能性不是没有!
甚至很高!
不过很快他就反应了过来,如果真是道主,何必弄这些小手段,一只大手把他抓住,顷刻炼化即可.
沉默片刻后,(昂霄)没有选择立刻夺舍(龙蛇盘影菩萨)拼死一搏,而是悄无声息地收回了意识.
冷静,局势还没有到最糟糕程度.
说穿了其实也就那样,不就是(白蜡金),(砂中土),(长流水),(覆灯火)全都莫名出了差错么.
话音落下,内冥府一阵沉默.
. 超!
下一秒,就见(昂霄)一掌将眼前的桌案拍成两半,这才算是将胸中那一股憋闷的恶气发泄了出去.
然而局势并不会因此而有所好转.
不过(昂霄)在发泄之后也重新恢复了镇定,开始认真思考破局之策,指尖更是搓出碎散火星.
‘破局点在何处.’
‘既然连(龙蛇盘影菩萨)都暴露了,那不用怀疑了,可以假定我最重要后手应该都已经暴露了.’
‘这种情况下,拿什么赢?’
渐渐的,(昂霄)眼底浮现出了一抹凶戾:(报世法外身),只有这一个底牌,是对方没办法针对的.
‘因为(报世法外身)并非谋划和算计,而是纯粹的实力,所以只要它还在,我就有决死反扑的机会. 换而言之,对方只要不傻,就肯定会想方设法让我用掉(报世法外身),彻底奠定胜局.’
那么答案就很简单了.
‘无论算计我人是不是鸿运,八成是一位圣宗出身的,既然如此,他算计我必然是更重要的利益.’
‘算计我只是顺带,是过程.’
‘所以我要做的就是忍耐. 无论幕后之人做什么,我都要沉住气,不能率先动用(报世法外身).’
‘直到幕后之人暴露了真正目的,才可以用(报世法外身)一击斩首. 唯有如此,我才有希望翻盘!’
想到这里,(昂霄)反而笑了.
多少年了,没想到临近我大计将成的时候,居然还能遇到危机如此巨大的,果然不可小觑天下人.
他更兴奋了.
昔日在刀尖上跳舞,在生死间游走紧张感再度浮现,却也让他沉寂许久的斗志在这一刻全面复苏.
事已至此,来吧!
(昂霄)站起身子,激昂而强烈的情绪在他的心中激荡,几近狂热,却让他的眼神愈发的冰冷理智:
且试试,你我谁的手段更高一筹!
`;

// 2. Nhập mã ngôn ngữ nguồn (thường là 'zh' cho tiếng Trung)
var testFrom = 'zh';

// 3. Nhập mã của prompt đích bạn muốn dùng (ID từ file language_list.js)
// !!! ĐỂ KIỂM TRA TÍNH NĂNG MỚI, HÃY ĐẶT GIÁ TRỊ NÀY LÀ 'vi_sac' !!!
// Các giá trị khác: 'default', 'en_literary', 'vi_vietlai'
var testTo = 'vi_sac';

// =======================================================================
// --- KẾT THÚC KHU VỰC CẤU HÌNH ---
// --- Không cần chỉnh sửa code bên dưới ---
// =======================================================================

var currentKeyIndex = 0;

function callGeminiAPI(text, prompt, apiKey) {
    if (!apiKey) { return { status: "error", message: "API Key không hợp lệ." }; }
    if (!text || text.trim() === '') { return { status: "success", data: "" }; }
    var full_prompt = prompt + "\n\n---\n\n" + text;
    var url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=" + apiKey;
    var body = {
        "contents": [{ "parts": [{ "text": full_prompt }] }],
        "generationConfig": { "temperature": 0.7, "topP": 0.95, "maxOutputTokens": 65536 },
        "safetySettings": [
            { "category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE" }
        ]
    };
    try {
        var response = fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        if (response.ok) {
            var result = JSON.parse(response.text());
            if (result.candidates && result.candidates.length > 0 && result.candidates[0].content) {
                return { status: "success", data: result.candidates[0].content.parts[0].text.trim() };
            }
            if (result.promptFeedback && result.promptFeedback.blockReason) {
                return { status: "blocked", message: "Bị chặn bởi Safety Settings: " + result.promptFeedback.blockReason };
            }
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + response.text() };
        } else {
            return { status: "key_error", message: "Lỗi HTTP " + response.status + " (API key có thể sai hoặc hết hạn mức)." };
        }
    } catch (e) {
        return { status: "error", message: "Ngoại lệ Javascript: " + e.toString() };
    }
}

function translateInChunksByLine(text, prompt) {
    var lines = text.split('\n');
    var translatedLines = [];
    var errorOccurred = false;
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.trim() === '') { translatedLines.push(''); continue; }
        var lineTranslated = false;
        for (var j = 0; j < apiKeys.length; j++) {
            var key = apiKeys[currentKeyIndex];
            var result = callGeminiAPI(line, prompt, key);
            if (result.status === "success") { translatedLines.push(result.data); lineTranslated = true; break; }
            if (result.status === "blocked") { translatedLines.push("..."); lineTranslated = true; break; }
            if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
            else { translatedLines.push("[LỖI DỊCH DÒNG: " + result.message + "]"); lineTranslated = true; errorOccurred = true; break; }
        }
        if (!lineTranslated) { translatedLines.push("[LỖI: TẤT CẢ API KEY ĐỀU KHÔNG HOẠT ĐỘNG]"); errorOccurred = true; }
    }
    if (errorOccurred) { return { status: "partial_error", data: translatedLines.join('\n') }; }
    return { status: "success", data: translatedLines.join('\n') };
}

function translateSingleChunk(chunkText, prompt) {
    for (var i = 0; i < apiKeys.length; i++) {
        var key = apiKeys[currentKeyIndex];
        var result = callGeminiAPI(chunkText, prompt, key);
        if (result.status === "success") { return result; }
        if (result.status === "blocked") { return translateInChunksByLine(chunkText, prompt); }
        if (result.status === "key_error") { currentKeyIndex = (currentKeyIndex + 1) % apiKeys.length; } 
        else { return result; }
    }
    return { status: "error", message: "Tất cả các API key đều không hoạt động." };
}

// Hàm thực thi chính
function execute(text, from, to) {
    // ---- GHI ĐÈ DỮ LIỆU TỪ ỨNG DỤNG BẰNG DỮ LIỆU THỬ NGHIỆM ----
    text = testText;
    from = testFrom;
    to = testTo;
    console.log("!!! CHẾ ĐỘ THỬ NGHIỆM ĐANG BẬT !!! Đang sử dụng dữ liệu được khai báo trong file. Đích: " + to);
    // -----------------------------------------------------------

    if (!apiKeys || apiKeys.length === 0 || (apiKeys[0].indexOf("YOUR_GEMINI_API_KEY") !== -1)) {
        return Response.error("Vui lòng cấu hình API key trong file apikey.js.");
    }
    if (!text || text.trim() === '') { return Response.success("?"); }

    var finalContent = "";

    if (to === 'vi_sac') {
        console.log("Phát hiện ngôn ngữ đích 'vi_sac'. Bắt đầu quy trình phiên âm Hán Việt...");
        try {
            load("phienam.js");
        } catch (e) {
            return Response.error("LỖI: Không thể tải file phienam.js. Hãy đảm bảo file này tồn tại trong cùng thư mục.");
        }
        
        var hanVietText = phienAmToHanViet(text);
        var selectedPrompt = prompts['vi_sac'];
        
        var result = callGeminiAPI(hanVietText, selectedPrompt, apiKeys[currentKeyIndex]);

        if (result.status === 'success') {
            finalContent = result.data;
        } else {
            finalContent = "\n\n<<<<<--- LỖI XỬ LÝ 'VI_SAC' --->>>>>\n" +
                           "Lý do: " + result.message + "\n" +
                           "<<<<<--- KẾT THÚC LỖI --->>>>>\n\n";
        }

    } else {
        var selectedPrompt = prompts[to] || prompts["default"];
        var textChunks = [];
        var CHUNK_SIZE = 5000;
        var MIN_LAST_CHUNK_SIZE = 1000;
        var INPUT_LENGTH_THRESHOLD = 10000;

        if (text.length > INPUT_LENGTH_THRESHOLD) {
            var tempChunks = [];
            for (var i = 0; i < text.length; i += CHUNK_SIZE) { tempChunks.push(text.substring(i, i + CHUNK_SIZE)); }
            if (tempChunks.length > 1 && tempChunks[tempChunks.length - 1].length < MIN_LAST_CHUNK_SIZE) {
                var lastChunk = tempChunks.pop();
                var secondLastChunk = tempChunks.pop();
                tempChunks.push(secondLastChunk + lastChunk);
            }
            textChunks = tempChunks;
        } else {
            textChunks.push(text);
        }

        var finalParts = [];
        for (var k = 0; k < textChunks.length; k++) {
            var chunkResult = translateSingleChunk(textChunks[k], selectedPrompt);
            if (chunkResult.status === 'success' || chunkResult.status === 'partial_error') {
                finalParts.push(chunkResult.data);
            } else {
                var errorString = "\n\n<<<<<--- LỖI DỊCH PHẦN " + (k + 1) + " --->>>>>\n" +
                                  "Lý do: " + chunkResult.message + "\n" +
                                  "<<<<<--- KẾT THÚC LỖI --->>>>>\n\n";
                finalParts.push(errorString);
            }
        }
        finalContent = finalParts.join('\n\n');
    }

    // --- BƯỚC XỬ LÝ CUỐI CÙNG (ÁP DỤNG CHO CẢ HAI LỘ TRÌNH) ---
    var lines = finalContent.split('\n');
    var finalOutput = "";
    for (var i = 0; i < lines.length; i++) {
        finalOutput += lines[i] + "\n";
    }

    return Response.success(finalOutput.trim());
}