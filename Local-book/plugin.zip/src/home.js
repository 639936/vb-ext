load('config.js');
function execute() {
        return Response.success([
            {title: "LIST",
            input: "",
            script: "gen.js"}
        ])
    }