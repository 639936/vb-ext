load("voice_list.js");

function execute(text, voice) {
    let cookie = localCookie.getCookie();
    if (!cookie || !cookie.includes("sessionid=")) {
        return Response.error("Bạn phải vào Tiktok đăng nhập trên trình duyệt để có thể đọc.");
    }
    let voiceInfo = voices.find(function (e) {
        return e.id == voice;
    });

    text = applyWordMap(text, edit_text);

    for (let i = 1; i <= 2; i++) {
        let response = fetch("https://api16-normal-c-useast1a.tiktokv.com/media/api/text/speech/invoke/", {
            method: 'POST',
            queries: {
                "text_speaker": voiceInfo.id,
                "req_text": text,
                "speaker_map_type": "0",
                "aid": "1233"
            },
            headers: {
                'User-Agent': 'com.zhiliaoapp.musically/2022600030 (Linux; U; Android 7.1.2; es_ES; SM-G988N; Build/NRD90M;tt-ok/3.12.13.1)',
                'Accept-Encoding': 'gzip,deflate,compress',
                'Cookie': cookie,
            }
        });

        if (!response.ok) {
            continue;
        }

        let resultText = response.text();

        // Parse JSON if it looks like JSON
        if (resultText.startsWith('{')) {
            let result = JSON.parse(resultText);
            let statusCode = result.status_code;

            if (statusCode === 0) {
                return Response.success(result.data.v_str);
            } else {
                return Response.error(result.status_msg);
            }
        }
    }
    return null;
}

// Hàm chính: Xử lý thay thế văn bản dựa trên config A=B
function applyWordMap(text, configStr) {
    if (!configStr) return text;

    text = text.toLowerCase();

    // Tách config thành từng dòng (hỗ trợ cả xuống dòng \n)
    let lines = configStr.split(/\r?\n/);

    for (let i = 0; i < lines.length; i++) {
        let line = lines[i].trim();
        if (line === "") continue; // Bỏ qua dòng trống

        // Tìm vị trí dấu = đầu tiên
        let separatorIndex = line.indexOf("=");
        
        // Nếu tìm thấy dấu = và nó không nằm ở đầu dòng
        if (separatorIndex > 0) {
            let key = line.substring(0, separatorIndex).trim();
            let value = line.substring(separatorIndex + 1).trim();

            if (key) {
                // Tạo Regex để thay thế toàn bộ (global)
                // escapeRegex giúp tránh lỗi nếu từ khóa chứa ký tự đặc biệt như ?, +, *
                let regex = new RegExp(escapeRegex(key), "g");
                text = text.replace(regex, value);
            }
        }
    }
    return text;
}

// Hàm phụ: Giúp xử lý các ký tự đặc biệt trong từ khóa khi tạo Regex
function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}