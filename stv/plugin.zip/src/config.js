let BASE_URL="http://14.225.254.182"
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
    
} catch (error) {
}