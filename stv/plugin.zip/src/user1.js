load("config.js");
function execute(url) {
    // http://14.225.254.182/io/bookfollow/getFollowedBooks?format=html&user=0&filter= theo dõi
    let response = fetch(BASE_URL+url)
    if (response.ok) {
        let doc = response.html()
        console.log(doc)
        let data = [];
        doc.select("body > a").forEach(e => {
            let name = doc.select(".bkr b").first().text();
            e.select(".bkr b").remove();
            let img = e.select("img").first().attr("src");
            if (img.startsWith('//')) img = img.replace('//', 'https://')
            data.push({
                name: name,
                link: e.attr("href"),
                cover: img,
                description: e.select(".bkr").text(),
                host: BASE_URL
            })
        });
        return Response.success(data)
    }
    return null;
}