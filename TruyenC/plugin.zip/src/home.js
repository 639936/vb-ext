function execute() {
    return Response.success([
        {
            input: "https://truyenc.com/truyen-sac-hiep",
            title: "Truyện sắc hiệp 709",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-sex",
            title: "Truyện Sex 399",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-kinh-di",
            title: "Truyện kinh dị 86",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-dai-ky",
            title: "Truyện ma dài kỳ 79",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-kiem-hiep",
            title: "Truyện kiếm hiệp 61",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-voz",
            title: "Truyện Voz 13",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-cuoi-khac",
            title: "Truyện cười khác 10",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-co-that",
            title: "Truyện có thật 9",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-dam-hiep",
            title: "Truyện dâm hiệp 9",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-co-that",
            title: "Truyện ma có thật 9",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-cuoi-dan-gian",
            title: "Truyện cười dân gian 6",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-cuoi-quoc-te",
            title: "Truyên cười quốc tế 5",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-sex-audio",
            title: "Truyện Sex Audio 2",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-trang-quynh",
            title: "Truyện trạng Quỳnh 2",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-cuoi-vova",
            title: "Truyện cười vova 1",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-trung-quoc",
            title: "Truyện ma Trung Quốc 1",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-viet-nam",
            title: "Truyện ma Việt Nam 1",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-audio",
            title: "Truyện ma audio 1",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-cuoi-18",
            title: "Truyện cười 18+ 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-cuoi-tinh-yeu",
            title: "Truyện cười tình yêu 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-ngan",
            title: "Truyện ma ngắn 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-hay",
            title: "Truyện ma hay 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-ma-nguyen-ngoc-ngan",
            title: "Truyện ma Nguyễn Ngọc Ngạn 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-audio-kiem-hiep",
            title: "Truyện audio kiếm hiệp 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-audio-ngon-tinh",
            title: "Truyện audio ngôn tình 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-dem-khuya",
            title: "Đọc truyện đêm khuya 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-audio-trinh-tham",
            title: "Truyện audio trinh thám 0",
            script: "gen.js"
        },
        {
            input: "https://truyenc.com/truyen-audio-ngan",
            title: "Truyện audio ngắn 0",
            script: "gen.js"
        }
    ]);
}