let languages = [
    {"id": "zh"},
    {"id": "en"},
    {"id": "vi"}
]

const languageMap = {
    "zh": "zh",
    "en": "en",
    "vi": "vie"
}