function bypass(url,cookie) {
    fetch(url, {
        headers: {
            "Cookie": "wkdth_code=lamondungtuyentruyen"
        }
    });
}