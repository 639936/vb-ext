let languages = [
    {"id": "zh"},
    {"id": "en"},
    {"id": "vi"},
    {"id": "ja"},
    {"id": "ko"}
];