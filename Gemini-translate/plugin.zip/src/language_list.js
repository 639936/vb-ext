let languages = [
    {"id": "zh-Hans"},
    {"id": "en"},
    {"id": "vi"},
    {"id": "ja"},
    {"id": "ko"},
    {"id": "zh-Hant"}
];