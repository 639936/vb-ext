let languages = [
    {"id": "en", "name": "English"},
    {"id": "vi", "name": "Vietnamese"},
    {"id": "zh-Hans", "name": "Chinese (Simplified)"},
    {"id": "zh-Hant", "name": "Chinese (Traditional)"},
    {"id": "ja", "name": "Japanese"},
    {"id": "ko", "name": "Korean"}
];