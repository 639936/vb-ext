load("language_list.js"); 
load("apikey.js");
load("prompt.js");
load("baidutranslate.js");

var modelsucess = "";
var models = [
    "gemini-2.5-pro",
    "gemini-2.5-flash-preview-05-20",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite"
];
var cacheableModels = ["gemini-2.5-pro", "gemini-2.5-flash-preview-05-20"];

function generateFingerprintCacheKey(lines) {
    var keyParts = "";
    var linesForId = lines.slice(0, 5); 
    for (var i = 0; i < linesForId.length; i++) {
        var line = linesForId[i].trim();
        if (line.length >= 6) { 
            keyParts += line.substring(0, 3) + line.slice(-3);
        } else {
            keyParts += line;
        }
    }
    return "vbook_fp_cache_" + keyParts;
}

/**
 * Quản lý và lưu bản dịch vào cache, đảm bảo không vượt quá giới hạn 100 mục.
 * @param {string} cacheKey - Key của nội dung cần lưu.
 * @param {string} contentToSave - Nội dung bản dịch cần lưu.
 */
function manageCacheAndSave(cacheKey, contentToSave) {
    const MAX_CACHE_SIZE = 50;
    const CACHE_MANIFEST_KEY = "vbook_cache_manifest";

    try {
        var manifest = [];
        var rawManifest = localStorage.getItem(CACHE_MANIFEST_KEY);
        if (rawManifest) {
            manifest = JSON.parse(rawManifest);
        }

        // Xóa các mục cũ nhất nếu cache đã đầy
        while (manifest.length >= MAX_CACHE_SIZE) {
            // Sắp xếp để mục cũ nhất (timestamp nhỏ nhất) ở đầu
            manifest.sort(function(a, b) { return a.ts - b.ts; });
            var oldestItem = manifest.shift(); // Lấy và xóa mục cũ nhất khỏi sổ
            if (oldestItem) {
                localStorage.removeItem(oldestItem.key);
            }
        }

        // Thêm mục mới vào sổ
        manifest.push({ key: cacheKey, ts: Date.now() });

        // Lưu lại sổ và bản dịch mới
        localStorage.setItem(CACHE_MANIFEST_KEY, JSON.stringify(manifest));
        localStorage.setItem(cacheKey, contentToSave);

    } catch (e) {
        // Nếu có lỗi, thử lưu trực tiếp để không làm gián đoạn
        try {
            localStorage.setItem(cacheKey, contentToSave);
        } catch (e2) {
            // Bỏ qua nếu vẫn lỗi
        }
    }
}

function callGeminiAPI(text, prompt, apiKey, model) {
    if (!apiKey) { return { status: "error", message: "API Key không hợp lệ." }; }
    if (!text || text.trim() === '') { return { status: "success", data: "" }; }
    modelsucess = model;
    var full_prompt = prompt + "\n\nDưới đây là văn bản cần xử lý\n\n" + text;
    var url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + apiKey;
    var body = {
        "contents": [{ "role": "user", "parts": [{ "text": full_prompt }] }],
        "generationConfig": { "temperature": 1.0, "topP": 1.0, "topK": 40, "maxOutputTokens": 65536 },
        "safetySettings": [
            { "category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE" }
        ]
    };
    try {
        var response = fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        var responseText = response.text(); 

        if (response.ok) {
            var result = JSON.parse(responseText);
            if (result.candidates && result.candidates.length > 0 && result.candidates[0].content && result.candidates[0].content.parts && result.candidates[0].content.parts.length > 0 && result.candidates[0].content.parts[0].text) {
                return { status: "success", data: result.candidates[0].content.parts[0].text.trim() };
            }
            if (result.promptFeedback && result.promptFeedback.blockReason) { return { status: "blocked", message: "Bị chặn bởi Safety Settings: " + result.promptFeedback.blockReason }; }
            if (result.candidates && result.candidates.length > 0 && (!result.candidates[0].content || !result.candidates[0].content.parts)) { return { status: "blocked", message: "Bị chặn (không có nội dung trả về)." }; }
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + responseText };
        } else {
            return { status: "key_error", message: "Lỗi HTTP " + response.status + ". Phản hồi từ server:\n" + responseText };
        }
    } catch (e) { return { status: "error", message: "Ngoại lệ Javascript: " + e.toString() }; }
}

function translateChunkWithApiRetry(chunkText, prompt, modelToUse, keysToTry) {
    var keyErrors = [];
    for (var i = 0; i < keysToTry.length; i++) {
        var apiKeyToUse = keysToTry[i];
        var result = callGeminiAPI(chunkText, prompt, apiKeyToUse, modelToUse);
        
        if (result.status === "success") {
            if ((result.data.length / chunkText.length) < 0.8) {
                result.status = "short_result_error";
                result.message = "Kết quả trả về ngắn hơn 80% so với văn bản gốc.";
            } else {
                return result; 
            }
        }
        
        keyErrors.push("  + Key " + (i + 1) + " (" + apiKeyToUse + "):\n    " + result.message.replace(/\n/g, '\n    '));

        if (i < keysToTry.length - 1) {
            try {
                sleep(100); 
            } catch (e) {
                // Bỏ qua lỗi
            }
        }
    }
    return { 
        status: 'all_keys_failed', 
        message: 'Tất cả API keys đều thất bại cho chunk này.',
        details: keyErrors 
    }; 
}

function execute(text, from, to) {
    if (!text || text.trim() === '') {
        return Response.success("?");
    }

    var apiKeyStorageKey = "vbook_last_api_key_index";
    var rotatedApiKeys = apiKeys; 
    try {
        if (apiKeys && apiKeys.length > 1) {
            var lastUsedIndex = parseInt(localStorage.getItem(apiKeyStorageKey) || "-1");
            var nextIndex = (lastUsedIndex + 1) % apiKeys.length;
            rotatedApiKeys = apiKeys.slice(nextIndex).concat(apiKeys.slice(0, nextIndex));
            localStorage.setItem(apiKeyStorageKey, nextIndex.toString());
        }
    } catch (e) {
        rotatedApiKeys = apiKeys;
    }

    if (from === 'vi') {
        models.reverse();
    }

    var lines = text.split('\n');

    if (to === 'vi_xoacache') {
        var isChapterContentForDelete = text.length >= 800;
        if (isChapterContentForDelete) {
            var shortLinesCountForDelete = 0;
            if (lines.length > 0) {
                for (var i = 0; i < lines.length; i++) { if (lines[i].length < 25) { shortLinesCountForDelete++; } }
                if ((shortLinesCountForDelete / lines.length) > 0.8) { isChapterContentForDelete = false; }
            }
        }
        if (isChapterContentForDelete) {
            var cacheKeyToDelete = generateFingerprintCacheKey(lines);
            if (localStorage.getItem(cacheKeyToDelete) !== null) {
                localStorage.removeItem(cacheKeyToDelete);

                const CACHE_MANIFEST_KEY = "vbook_cache_manifest";
                try {
                    var rawManifest = localStorage.getItem(CACHE_MANIFEST_KEY);
                    if (rawManifest) {
                        var manifest = JSON.parse(rawManifest);
                        var updatedManifest = manifest.filter(function(item) {
                            return item.key !== cacheKeyToDelete;
                        });
                        localStorage.setItem(CACHE_MANIFEST_KEY, JSON.stringify(updatedManifest));
                    }
                } catch (e) {
                    // Bỏ qua lỗi
                }

                return Response.success("Đã xóa cache thành công." + text);
            } else {
                return Response.success(text); 
            }
        } else {
            return Response.success(text);
        }
    }
    
    var isUsingBaidu = false;
    var lengthThreshold = 1000;   
    var lineLengthThreshold = 25; 
    if (to === 'vi_vietlai') {
        lengthThreshold = 1500;
        lineLengthThreshold = 50;
    }
    if (text.length < lengthThreshold) {
        isUsingBaidu = true;
    } else {
        var shortLinesCount = 0;
        var totalLines = lines.length;
        if (totalLines > 0) {
            for (var i = 0; i < totalLines; i++) {
                if (lines[i].length < lineLengthThreshold) { shortLinesCount++; }
            }
            if ((shortLinesCount / totalLines) > 0.8) {
                isUsingBaidu = true;
            }
        }
    }

    if (to === 'vi_vietlai' && isUsingBaidu) {
        return Response.success(text);
    }

    var cacheKey = null;
    var finalContent = "";

    if (!isUsingBaidu) {
        try {
            cacheKey = generateFingerprintCacheKey(lines);
            var cachedTranslation = localStorage.getItem(cacheKey);
            if (cachedTranslation) {
                return Response.success(cachedTranslation);
            }
        } catch (e) {
            cacheKey = null;
        }
    }
    
    if (isUsingBaidu) {
        var baiduFromLang = from;
        var vietnameseToLanguages = ['vi_tieuchuan', 'vi_sac', 'vi_vietlai', 'vi_NameEng', 'vi_layname'];
        if (from === 'vi' && vietnameseToLanguages.indexOf(to) > -1) {
            baiduFromLang = 'zh';
        }
        const BAIDU_CHUNK_SIZE = 500;
        var baiduTranslatedParts = [];
        var baiduToLang = (to === 'vi_sac' || to === 'vi_vietlai' || to === 'vi_NameEng' || to === 'vi_tieuchuan' || to === 'vi_layname') ? 'vi' : to;
        for (var i = 0; i < lines.length; i += BAIDU_CHUNK_SIZE) {
            var currentChunkLines = lines.slice(i, i + BAIDU_CHUNK_SIZE);
            var chunkText = currentChunkLines.join('\n');
            var translatedChunk = baiduTranslateContent(chunkText, baiduFromLang, baiduToLang, 0); 
            if (translatedChunk === null) {
                return Response.error("Lỗi Baidu Translate. Vui lòng thử lại.");
            }
            baiduTranslatedParts.push(translatedChunk);
        }
        finalContent = baiduTranslatedParts.join('\n');
    } else {
        if (!rotatedApiKeys || rotatedApiKeys.length === 0) { return Response.error("LỖI: Vui lòng cấu hình ít nhất 1 API key."); }
        if (!models || models.length === 0) { return Response.error("LỖI: Vui lòng cấu hình ít nhất 1 model."); }
        
        var selectedPrompt = prompts[to] || prompts["vi"];
        var pinyinLanguages = ['vi_tieuchuan', 'vi_sac', 'vi_NameEng', 'vi_layname'];
        var isPinyinRoute = pinyinLanguages.indexOf(to) > -1;
        var translationSuccessful = false;
        var errorLog = {};

        for (var m = 0; m < models.length; m++) {
            var modelToUse = models[m];
            var CHUNK_SIZE = 4000;
            var MIN_LAST_CHUNK_SIZE = 1000;
            if (modelToUse === "gemini-2.5-flash" || modelToUse === "gemini-2.5-flash-preview-05-20" || modelToUse === "gemini-2.5-pro") {
                CHUNK_SIZE = 2000;
                MIN_LAST_CHUNK_SIZE = 1000;
            }

            var textChunks = [];
            var currentChunk = "";
            var currentChunkLineCount = 0;
            const MAX_LINES_PER_CHUNK = 50;

            for (var i = 0; i < lines.length; i++) {
                var paragraph = lines[i];
                if (currentChunk.length === 0 && paragraph.length >= CHUNK_SIZE) {
                    textChunks.push(paragraph);
                    continue;
                }
                if ( (currentChunk.length + paragraph.length + 1 > CHUNK_SIZE || currentChunkLineCount >= MAX_LINES_PER_CHUNK) && currentChunk.length > 0 ) {
                    textChunks.push(currentChunk);
                    currentChunk = paragraph;
                    currentChunkLineCount = 1;
                } else {
                    currentChunk = currentChunk ? (currentChunk + "\n" + paragraph) : paragraph;
                    currentChunkLineCount++;
                }
            }
            if (currentChunk.length > 0) {
                textChunks.push(currentChunk);
            }
            if (textChunks.length > 1 && textChunks[textChunks.length - 1].length < MIN_LAST_CHUNK_SIZE) {
                var lastChunk = textChunks.pop();
                var secondLastChunk = textChunks.pop();
                textChunks.push(secondLastChunk + "\n" + lastChunk);
            }

            var finalParts = [];
            var currentModelFailed = false;
            for (var k = 0; k < textChunks.length; k++) {
                var chunkToSend = textChunks[k];
                if (isPinyinRoute) {
                    try {
                        load("phienam.js");
                        chunkToSend = phienAmToHanViet(chunkToSend);
                    } catch (e) { return Response.error("LỖI: Không thể tải file phienam.js."); }
                }
                
                var chunkResult = translateChunkWithApiRetry(chunkToSend, selectedPrompt, modelToUse, rotatedApiKeys);
                
                if (chunkResult.status === 'success') {
                    finalParts.push(chunkResult.data);
                } else {
                    errorLog[modelToUse] = chunkResult.details;
                    currentModelFailed = true;
                    break; 
                }
            }

            if (!currentModelFailed) {
                finalContent = modelsucess + " . " + finalParts.join('\n\n');
                translationSuccessful = true;
                break; 
            }
        } 

        if (!translationSuccessful) {
            var errorString = "<<<<<--- LỖI DỊCH (ĐÃ THỬ HẾT CÁC MODEL) --->>>>>\n";
            for (var modelName in errorLog) {
                errorString += "\n--- Chi tiết lỗi với Model: " + modelName + " ---\n";
                errorString += errorLog[modelName].join("\n");
                errorString += "\n";
            }
            errorString += "\n<<<<<--- KẾT THÚC BÁO CÁO LỖI --->>>>>";
            finalContent = errorString;
            return Response.error;
        }
    }

    if (cacheKey && finalContent && !finalContent.includes("LỖI DỊCH") && to !== 'vi_layname') {
        if (cacheableModels.indexOf(modelsucess) > -1) {
            manageCacheAndSave(cacheKey, finalContent.trim());
        }
    }
    
    return Response.success(finalContent.trim());
}