load("language_list.js");
load("apikey.js");
load("prompt.js");
load("baidutranslate.js");

var modelsucess = "";
var models = [
    "gemini-2.5-pro",
    "gemini-2.5-flash-preview-05-20",
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite"
];
var cacheableModels = ["gemini-2.5-pro", "gemini-2.5-flash-preview-05-20"];

function generateFingerprintCacheKey(lines) {
    var keyParts = "";
    var linesForId = lines.slice(0, 5);
    for (var i = 0; i < linesForId.length; i++) {
        var line = linesForId[i].trim();
        if (line.length >= 6) {
            keyParts += line.substring(0, 3) + line.slice(-3);
        } else {
            keyParts += line;
        }
    }
    return "vbook_fp_cache_" + keyParts;
}

function manageCacheAndSave(cacheKey, contentToSave) {
    const MAX_CACHE_SIZE = 50;
    const CACHE_MANIFEST_KEY = "vbook_cache_manifest";
    try {
        var manifest = [];
        var rawManifest = localStorage.getItem(CACHE_MANIFEST_KEY);
        if (rawManifest) {
            manifest = JSON.parse(rawManifest);
        }
        while (manifest.length >= MAX_CACHE_SIZE) {
            manifest.sort(function(a, b) { return a.ts - b.ts; });
            var oldestItem = manifest.shift();
            if (oldestItem) {
                localStorage.removeItem(oldestItem.key);
            }
        }
        manifest.push({ key: cacheKey, ts: Date.now() });
        localStorage.setItem(CACHE_MANIFEST_KEY, JSON.stringify(manifest));
        localStorage.setItem(cacheKey, contentToSave);
    } catch (e) {
        console.log("Lỗi khi quản lý cache: " + e.toString());
        try {
            localStorage.setItem(cacheKey, contentToSave);
        } catch (e2) {
            console.log("Lỗi khi lưu cache trực tiếp: " + e2.toString());
        }
    }
}

function callGeminiAPI(text, prompt, apiKey, model) {
    if (!apiKey) { return { status: "error", message: "API Key không hợp lệ." }; }
    if (!text || text.trim() === '') { return { status: "success", data: "" }; }
    modelsucess = model;
    var full_prompt = prompt + "\n\nDưới đây là văn bản cần xử lý\n\n" + text;
    var url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + apiKey;
    var body = {
        "contents": [{ "role": "user", "parts": [{ "text": full_prompt }] }],
        "generationConfig": { "temperature": 1.0, "topP": 1.0, "topK": 40, "maxOutputTokens": 65536 },
        "safetySettings": [
            { "category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE" },
            { "category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE" }
        ]
    };
    try {
        var response = fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        var responseText = response.text();
        if (response.ok) {
            var result = JSON.parse(responseText);
            if (result.candidates && result.candidates[0].content && result.candidates[0].content.parts && result.candidates[0].content.parts[0].text) {
                return { status: "success", data: result.candidates[0].content.parts[0].text.trim() };
            }
            if (result.promptFeedback && result.promptFeedback.blockReason) { return { status: "blocked", message: "Bị chặn bởi Safety Settings: " + result.promptFeedback.blockReason }; }
            if (result.candidates && (!result.candidates[0].content || !result.candidates[0].content.parts)) { return { status: "blocked", message: "Bị chặn (không có nội dung trả về)." }; }
            return { status: "error", message: "API không trả về nội dung hợp lệ. Phản hồi: " + responseText };
        } else {
            return { status: "key_error", message: "Lỗi HTTP " + response.status + ". Phản hồi từ server:\n" + responseText };
        }
    } catch (e) { 
        var errorMessage = "Ngoại lệ Javascript trong callGeminiAPI: " + e.toString();
        console.log(errorMessage);
        return { status: "error", message: errorMessage }; 
    }
}

function translateChunkWithApiRetry(chunkText, prompt, modelToUse, keysToTry) {
    var keyErrors = [];
    for (var i = 0; i < keysToTry.length; i++) {
        var apiKeyToUse = keysToTry[i];
        var result = callGeminiAPI(chunkText, prompt, apiKeyToUse, modelToUse);
        if (result.status === "success") {
            if ((result.data.length / chunkText.length) < 0.8 && chunkText.length > 100) {
                result.status = "short_result_error";
                result.message = "Kết quả trả về ngắn hơn 80% so với văn bản gốc.";
            } else {
                result.usedKey = apiKeyToUse;
                return result;
            }
        }
        keyErrors.push("  + Key " + (apiKeys.indexOf(apiKeyToUse) + 1) + " (" + apiKeyToUse.substring(0, 4) + "...):\n    " + result.message.replace(/\n/g, '\n    '));
        if (result.status === "key_error" || result.status === "blocked") {
            result.failedKey = apiKeyToUse;
        }
        if (i < keysToTry.length - 1) {
            try { sleep(100); } catch (e) { /* Bỏ qua */ }
        }
    }
    return {
        status: 'all_keys_failed',
        message: 'Tất cả API keys đều thất bại cho chunk này.',
        details: keyErrors
    };
}

function handleGeminiTranslation(text, from, effectiveTo, rotatedApiKeys) {
    var lines = text.split('\n');
    var modelsToIterate;
    if (from.startsWith('gen_')) {
        var modelMap = {
            'gen_2.5pro': 'gemini-2.5-pro',
            'gen_2.5flash_preview': 'gemini-2.5-flash-preview-05-20',
            'gen_2.5flash': 'gemini-2.5-flash',
            'gen_2.5flash_lite': 'gemini-2.5-flash-lite'
        };
        modelsToIterate = [modelMap[from]];
    } else {
        modelsToIterate = models;
    }

    var fromLangForPrompt = from;
    if (from === 'en' && effectiveTo !== 'zh') {
        effectiveTo = 'vi';
    } else if (['zh', 'en', 'vi'].indexOf(from) === -1 && !from.startsWith('gen_')) {
        fromLangForPrompt = 'zh';
    }
    
    var selectedPrompt = prompts[effectiveTo] || prompts["vi"];
    var pinyinLanguages = ['vi_tieuchuan', 'vi_sac', 'vi_NameEng', 'vi_layname'];

    var isPinyinRoute = pinyinLanguages.indexOf(effectiveTo) > -1 && (fromLangForPrompt === 'zh' || from.startsWith('gen_'));

    var errorLog = {};

    for (var m = 0; m < modelsToIterate.length; m++) {
        var modelToUse = modelsToIterate[m];
        if (!modelToUse) continue;
        
        var availableKeysForModel = rotatedApiKeys.slice(0);

        var CHUNK_SIZE, MIN_LAST_CHUNK_SIZE;
        if (modelToUse === "gemini-2.5-pro") {
            CHUNK_SIZE = 1500;
            MIN_LAST_CHUNK_SIZE = 600;
        } else if (modelToUse === "gemini-2.5-flash" || modelToUse === "gemini-2.5-flash-preview-05-20") {
            CHUNK_SIZE = 2000;
            MIN_LAST_CHUNK_SIZE = 600;
        } else if (modelToUse === "gemini-2.5-flash-lite") {
            CHUNK_SIZE = 4000;
            MIN_LAST_CHUNK_SIZE = 1000;
        } else {
            CHUNK_SIZE = 4000;
            MIN_LAST_CHUNK_SIZE = 2000;
        }
        
        var textChunks = [], currentChunk = "";
        for (var i = 0; i < lines.length; i++) {
            var paragraph = lines[i];
            if (currentChunk.length === 0 && paragraph.length >= CHUNK_SIZE) {
                textChunks.push(paragraph);
                continue;
            }
            if ((currentChunk.length + paragraph.length + 1 > CHUNK_SIZE) && currentChunk.length > 0) {
                textChunks.push(currentChunk);
                currentChunk = paragraph;
            } else {
                currentChunk = currentChunk ? (currentChunk + "\n" + paragraph) : paragraph;
            }
        }
        if (currentChunk.length > 0) textChunks.push(currentChunk);

        if (textChunks.length > 1 && textChunks[textChunks.length - 1].length < MIN_LAST_CHUNK_SIZE) {
            var lastChunk = textChunks.pop();
            textChunks.push(textChunks.pop() + "\n" + lastChunk);
        }
        
        var finalParts = [], currentModelFailed = false;

        for (var k = 0; k < textChunks.length; k++) {
            var chunkToSend = textChunks[k];
            if (isPinyinRoute) {
                try {
                    load("phienam.js");
                    chunkToSend = phienAmToHanViet(chunkToSend);
                } catch (e) {
                    var phienamError = "LỖI: Không thể tải file phienam.js.";
                    console.log(phienamError);
                    return Response.error(phienamError);
                }
            }
            
            var chunkResult = translateChunkWithApiRetry(chunkToSend, selectedPrompt, modelToUse, availableKeysForModel);
            
            if (chunkResult.status === 'success') {
                finalParts.push(chunkResult.data);
                var successfulKey = chunkResult.usedKey;
                availableKeysForModel = availableKeysForModel.filter(function(key) { return key !== successfulKey; });
                availableKeysForModel.unshift(successfulKey);
            } else {
                if(chunkResult.failedKey) {
                    availableKeysForModel = availableKeysForModel.filter(function(key) { return key !== chunkResult.failedKey; });
                }
                if (availableKeysForModel.length === 0 || chunkResult.status === 'all_keys_failed') {
                    errorLog[modelToUse] = chunkResult.details;
                    console.log("Model '" + modelToUse + "' thất bại do hết key hợp lệ hoặc tất cả key đều lỗi.");
                    currentModelFailed = true;
                    break;
                }
            }
        }

        if (!currentModelFailed) {
            modelsucess = modelToUse;
            return modelsucess + " . " + finalParts.join('\n\n');
        }
    }

    var errorString = "<<<<<--- LỖI DỊCH (ĐÃ THỬ HẾT CÁC MODEL) --->>>>>\n";
    for (var modelName in errorLog) {
        errorString += "\n--- Chi tiết lỗi với Model: " + modelName + " ---\n";
        errorString += (errorLog[modelName] || []).join("\n") + "\n";
    }
    console.log(errorString);
    return Response.error(errorString);
}

function handleBaiduTranslation(text, from, effectiveTo) {
    var lines = text.split('\n');
    var baiduToLang;
    if (['vi', 'zh', 'en'].indexOf(effectiveTo) > -1) {
        baiduToLang = effectiveTo;
    } else {
        baiduToLang = 'vi';
    }

    const BAIDU_CHUNK_SIZE = 500;
    var baiduTranslatedParts = [];
    for (var i = 0; i < lines.length; i += BAIDU_CHUNK_SIZE) {
        var chunkText = lines.slice(i, i + BAIDU_CHUNK_SIZE).join('\n');
        var translatedChunk = baiduTranslateContent(chunkText, "auto", baiduToLang, 0);
        if (translatedChunk === null) {
            var baiduError = "Lỗi Baidu Translate. Vui lòng thử lại.";
            console.log(baiduError);
            return Response.error(baiduError);
        }
        baiduTranslatedParts.push(translatedChunk);
    }
    return baiduTranslatedParts.join('\n');
}

function execute(text, from, to) {
    if (!text || text.trim() === '') {
        return Response.success("?");
    }

    if (to === 'vi_xoacache') {
        var isChapterContentForDelete = text.length >= 800;
        var linesForDelete = text.split('\n');
        if (isChapterContentForDelete) {
            var shortLinesCountForDelete = 0;
            if (linesForDelete.length > 0) {
                for (var i = 0; i < linesForDelete.length; i++) { if (linesForDelete[i].length < 25) { shortLinesCountForDelete++; } }
                if ((shortLinesCountForDelete / linesForDelete.length) > 0.8) { isChapterContentForDelete = false; }
            }
        }
        if (isChapterContentForDelete) {
            var cacheKeyToDelete = generateFingerprintCacheKey(linesForDelete);
            if (localStorage.getItem(cacheKeyToDelete) !== null) {
                localStorage.removeItem(cacheKeyToDelete);
                const CACHE_MANIFEST_KEY = "vbook_cache_manifest";
                try {
                    var rawManifest = localStorage.getItem(CACHE_MANIFEST_KEY);
                    if (rawManifest) {
                        var manifest = JSON.parse(rawManifest);
                        var updatedManifest = manifest.filter(function(item) { return item.key !== cacheKeyToDelete; });
                        localStorage.setItem(CACHE_MANIFEST_KEY, JSON.stringify(updatedManifest));
                    }
                } catch (e) { /* Bỏ qua */ }
                return Response.success("Đã xóa cache thành công." + text);
            }
        }
        return Response.success(text);
    }

    var effectiveTo = to;
    if (to.startsWith('gen_')) {
        effectiveTo = 'vi_tieuchuan';
    }

    var rotatedApiKeys = apiKeys;
    try {
        if (apiKeys && apiKeys.length > 1) {
            var lastUsedIndex = parseInt(localStorage.getItem("vbook_last_api_key_index") || "-1");
            var nextIndex = (lastUsedIndex + 1) % apiKeys.length;
            rotatedApiKeys = apiKeys.slice(nextIndex).concat(apiKeys.slice(0, nextIndex));
            localStorage.setItem("vbook_last_api_key_index", nextIndex.toString());
        }
    } catch (e) { console.log("Lỗi khi xoay vòng API key: " + e.toString()); }
    
    if (!rotatedApiKeys || rotatedApiKeys.length === 0) {
        var noApiKeyError = "LỖI: Vui lòng cấu hình ít nhất 1 API key.";
        console.log(noApiKeyError);
        return Response.error(noApiKeyError); 
    }

    var lines = text.split('\n');
    var finalContent = "";
    var isUsingBaidu = false;
    var lengthThreshold = 1000, lineLengthThreshold = 25;

    if (effectiveTo === 'vi_vietlai') {
        lengthThreshold = 1500;
        lineLengthThreshold = 50;
    }

    if (text.length < lengthThreshold) {
        isUsingBaidu = true;
    } else {
        var shortLinesCount = lines.filter(function(l) { return l.length < lineLengthThreshold; }).length;
        if (lines.length > 0 && (shortLinesCount / lines.length) > 0.8) {
            isUsingBaidu = true;
        }
    }
    
    if (effectiveTo === 'vi_vietlai' && isUsingBaidu) {
        return Response.success(text);
    }

    if (isUsingBaidu) {
        var isStandardPair = ['zh', 'en', 'vi'].indexOf(from) > -1 && ['zh', 'en', 'vi'].indexOf(effectiveTo) > -1;
        if (isStandardPair) {
            isUsingBaidu = false;
        }
    }

    var cacheKey = null;
    if (!isUsingBaidu) {
        try {
            cacheKey = generateFingerprintCacheKey(lines);
            var cachedTranslation = localStorage.getItem(cacheKey);
            if (cachedTranslation) {
                return Response.success(cachedTranslation);
            }
        } catch (e) {
            console.log("Lỗi khi kiểm tra cache: " + e.toString());
            cacheKey = null;
        }
    }

    if (isUsingBaidu) {
        finalContent = handleBaiduTranslation(text, from, effectiveTo);
    } else {
        finalContent = handleGeminiTranslation(text, from, effectiveTo, rotatedApiKeys);
    }
    
    if (finalContent.hasOwnProperty('status') && finalContent.status === 'error') {
        return Response.error;
    }

    if (cacheKey && finalContent && !finalContent.includes("LỖI DỊCH")) {
        if (cacheableModels.indexOf(modelsucess) > -1 && effectiveTo !== 'vi_layname') {
            manageCacheAndSave(cacheKey, finalContent.trim());
        }
    }
    
    return Response.success(finalContent.trim());
}