var testText = 'Nhiệm vụ: Phân tích văn bản Hán Việt, dịch ngược các thuật ngữ sang chữ Hán (Hán Tự) và cung cấp nghĩa theo quy tắc.\n\n## Quy tắc:\n1.  **Định dạng đầu ra:**\n    -   Chỉ trả về một khối văn bản thuần, KHÔNG markdown, không giải thích.\n    -   Sử dụng chính xác các đầu mục và thứ tự sau:\n        tên:\n        đại từ nhân xưng:\n        giới từ:\n        danh từ chung:\n        trợ từ:\n        câu có quy tắc:\n    -   Nếu một mục không có nội dung, hãy để trống bên dưới đầu mục đó.\n\n2.  **Quy tắc ánh xạ:**\n    -   Định dạng: \"Chữ Hán=Nghĩa\", mỗi cặp một dòng.\n    -   **Với mục \"tên:\":**\n        -   Nghĩa = Tên Hán Việt gốc (VD: `林雨=Lâm Vũ`).\n        -   Nếu là tên phiên âm, Nghĩa = Tên tiếng Anh (VD: `拉塔托斯克=Ratatoskr`).\n    -   **Với TẤT CẢ CÁC MỤC CÒN LẠI:**\n        -   Nghĩa = Nghĩa thuần Việt phổ thông, TUYỆT ĐỐI KHÔNG dùng lại từ Hán Việt.\n        -   Đúng: `声音=âm thanh`, `眼睛=mắt`.\n        -   Sai: `声音=thanh âm`, `眼睛=nhãn tình`.\n\n3.  **Trích xuất mẫu câu:**\n    -   Áp dụng cho mục \"- câu có quy tắc:\".\n    -   Xác định cấu trúc lặp lại có thể thay thế thành phần (biến) tên/đại từ nhân xưng/giới từ/danh từ chung/trợ từ, thay thế 1-2 (biến) đó bằng `{0}` và `{1}`.\n    -   Định dạng: \"Mẫu câu chữ Hán=Mẫu câu tiếng Việt với {biến}\".\n    -   VD: 你真是美丽 sẽ phân tích thành: `{0}真是{1}={0} thật là {1}`.';

function execute(text, from, to) {
    text = testText;
    // Trường hợp 1: Văn bản đầu vào rỗng hoặc chỉ chứa khoảng trắng.
    if (!text || text.trim() === '') {
        return Response.success("Văn bản rỗng. Độ dài: 0 ký tự.");
    }

    // Trường hợp 2: Văn bản có nội dung.
    // Lấy độ dài của chuỗi văn bản.
    var length = text.length;
    
    // Tạo chuỗi kết quả để hiển thị cho người dùng.
    var resultMessage = "Độ dài của văn bản là: " + length + " ký tự.";
    
    // Trả về kết quả thành công.
    return Response.success(resultMessage);
}