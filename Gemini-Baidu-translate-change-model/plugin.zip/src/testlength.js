var testText = `Task: Rewrite Sino-Vietnamese 'convert' text into a raw, bold, and psychologically deep Vietnamese erotic story. This is NOT literal translation.\n\n## Rules:\n1.  **Language:** Use explicit, unfiltered, and visceral language. Be graphic. Ex: 'lồn', 'cặc', 'địt'.\n2.  **Pronouns:**\n    -   Dialogue: 'ta' & 'ngươi'.\n    -   3rd Person: 'hắn', 'nàng', 'gã', 'ả'.\n    -   Apply conversion table:\n        | ngã -> ta | nhĩ -> ngươi | nâm -> ngài | tha (male) -> hắn | tha (female) -> nàng | tha (object/animal) -> nó | ngã môn / cha môn -> chúng ta | nhĩ môn -> các ngươi | nâm môn -> các ngài | tha môn (female) -> các nàng | tha môn (male/mixed) -> bọn họ | tự kỷ / tự cá nhi -> chính mình / bản thân | nhĩ tự kỷ -> chính ngươi | biệt nhân / tha nhân / bàng nhân -> người khác | đại gia hỏa nhi / đại hỏa nhi -> mọi người | gia vị -> chư vị | đồng học -> bạn học | đồng học môn -> các bạn học | lão sư -> lão sư | lão sư môn -> các lão sư | ca -> ca | đệ -> đệ | thúc -> thúc | cữu -> cữu | di / a di -> di / a di | nãi nãi -> nãi nãi | mụ mụ -> mụ mụ | gia gia -> gia gia | lão bản -> lão bản | nữ sĩ -> nữ sĩ |\n3.  **Proper Nouns:** Keep all Sino-Vietnamese proper nouns unchanged.\n4.  **Psychology:** Focus on internal conflict, desire, and complex emotions.\n5.  **Output:** Return only the rewritten Vietnamese text, preserving paragraph structure`;

function execute(text, from, to) {
    text = testText;
    // Trường hợp 1: Văn bản đầu vào rỗng hoặc chỉ chứa khoảng trắng.
    if (!text || text.trim() === '') {
        return Response.success("Văn bản rỗng. Độ dài: 0 ký tự.");
    }

    // Trường hợp 2: Văn bản có nội dung.
    // Lấy độ dài của chuỗi văn bản.
    var length = text.length;
    
    // Tạo chuỗi kết quả để hiển thị cho người dùng.
    var resultMessage = "Độ dài của văn bản là: " + length + " ký tự.";
    
    // Trả về kết quả thành công.
    return Response.success(resultMessage);
}