
var apiKeys = [];
// Key duy nhất để đọc toàn bộ danh sách
var storageKey = "vbook_gemini_keys_list";

try {
    var keysString = localStorage.getItem(storageKey);
    if (keysString && keysString.trim() !== "") {
        // Tách chuỗi thành mảng, lọc ra các dòng trống có thể có
        apiKeys = keysString.split('\n').filter(function(key) {
            return key.trim() !== "";
        });
    }
} catch (e) {
    console.log("Lỗi khi đọc API keys từ localStorage: " + e.toString());
}

if (apiKeys.length === 0) {
    console.log("Không tìm thấy API key nào trong localStorage.");
} else {
    console.log("Đã tải thành công " + apiKeys.length + " API key từ localStorage.");
}