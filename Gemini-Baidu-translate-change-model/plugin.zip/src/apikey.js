
var apiKeys = [];
var keyPrefix = "gemini_key_";

try {
    // Vòng lặp để quét toàn bộ localStorage
    for (var i = 0; i < localStorage.length; i++) {
        var keyName = localStorage.key(i);
        // Kiểm tra xem key có bắt đầu bằng tiền tố của chúng ta không
        if (keyName && keyName.startsWith(keyPrefix)) {
            // Lấy giá trị (chính là API key) và thêm vào mảng
            apiKeys.push(localStorage.getItem(keyName));
        }
    }
} catch (e) {
    // Nếu có lỗi, mảng apiKeys sẽ rỗng, và translate.js sẽ tự xử lý
    console.log("Lỗi khi đọc API keys từ localStorage: " + e.toString());
}

// In ra log để dễ dàng kiểm tra
if (apiKeys.length === 0) {
    console.log("Không tìm thấy API key nào trong localStorage.");
} else {
    console.log("Đã tải thành công " + apiKeys.length + " API key từ localStorage.");
}