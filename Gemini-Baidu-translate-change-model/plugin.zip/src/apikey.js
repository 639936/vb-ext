// File: apikey.js

// --- BƯỚC 1: LUÔN TẠO MỘT PHƯƠNG ÁN DỰ PHÒNG AN TOÀN ---
// Khai báo một danh sách key mặc định.
// Script sẽ sử dụng danh sách này nếu không thể đọc từ localStorage hoặc localStorage rỗng.
// Để test, bạn có thể điền key của mình vào đây. Khi phát hành, có thể để mảng rỗng [].
var apiKeys = [
    "AIzaSyBDUHswiHfWmhWfgw129gbFZ8FI8p49bm0",
    "AIzaSyA5eE1ZukNGzjC5uaR2amXVPMGO35H4nF0",
    "AIzaSyCcGTq6p6-0G2he8FwLftCS0Xpz8gDnOjI",
    "AIzaSyCw6te_UNNBHnsXFflFk0eUWCirjpYakqA",
    "AIzaSyBJnazTOjn-1t9RVp05lhsqzYDHnnWrleM",
    "AIzaSyDmGhtbY8_XKG3xgRczzLCUVOlR6l7a4sw",
    "AIzaSyDrMKhxWjF8hWBLvFJWPN1JmmCEqwwf1Jg",
    "AIzaSyD7QFbDMkRT2hl44ivmyszdazWI5kT_88Q",
    "AIzaSyCbxFmJhrDURrVj7FwuyWQhZ9uYPlVtwQY",
    "AIzaSyDcUkX__sqArWtg8El1BgWcTAAk7snGWs0",
    "AIzaSyAbxEjurpGJZJgogiHRJm_GievC-ZIp2rA",
    "AIzaSyD2rGnXBGDKSgc0KVraY8_6H7x6ESmjKIA",
    "AIzaSyBo_tB4kKWJ8cqn7_x6iJMBi1RxB_FkrIc",
    "AIzaSyCWZuVP-VMg2xKtn-v4nZ0JnBXVcK5y74E",
    "AIzaSyAwBsV082dTEgO6LY3Fu8bNYKB5wmuoJmQ",
    "AIzaSyCRFluG5VbLYBE7E-T0lccYfb7fJKINuSs",
    "AIzaSyCCwxDldEJjNujCKWFRtbpOpvUZMuP5ZoE",
    "AIzaSyBj8Qr2mKk1zZ7YEYQeZCHC-aiVkmkoTJs",
    "AIzaSyAm1i6TrW9BA-XInO_WKQtcwIrDgxmlGJQ",
    "AIzaSyBOgOorQknIO2dMZvcKIIBV2-e2NyJoAjo",
    "AIzaSyBULWq4c-Zy49UsFPpxgY74hJBLkQCg4G0"
];

// --- BƯỚC 2: GÓI LOGIC "RỦI RO" VÀO MỘT HÀM RIÊNG BIỆT ---
/**
 * Cố gắng đọc và phân tích cú pháp danh sách key từ localStorage.
 * Trả về một mảng các key nếu thành công.
 * Trả về null nếu môi trường không hỗ trợ hoặc có lỗi xảy ra.
 */
function loadKeysFromStorage() {
    // Kiểm tra kỹ lưỡng sự tồn tại của localStorage trước khi sử dụng
    if (typeof localStorage === 'undefined' || !localStorage) {
        console.log("Môi trường không hỗ trợ localStorage.");
        return null;
    }

    try {
        var storageKey = "vbook_gemini_keys_list";
        var keysString = localStorage.getItem(storageKey);

        if (keysString && keysString.trim() !== "") {
            // Thành công, trả về một mảng các key
            return keysString.split('\n').filter(function(key) {
                return key.trim() !== "";
            });
        } else {
            // localStorage trống, trả về mảng rỗng (đây là trường hợp hợp lệ)
            return [];
        }
    } catch (e) {
        // Có lỗi xảy ra trong quá trình đọc
        console.log("Lỗi khi đọc API keys từ localStorage: " + e.toString());
        return null; // Trả về null để báo hiệu có lỗi
    }
}

// --- BƯỚC 3: CHỈ GHI ĐÈ KHI THỰC SỰ AN TOÀN ---
var keysFromStorage = loadKeysFromStorage();

// 'keysFromStorage' sẽ là một mảng (có thể rỗng) nếu thành công, hoặc null nếu thất bại.
// Chúng ta chỉ ghi đè apiKeys nếu 'keysFromStorage' không phải là null.
if (keysFromStorage !== null) {
    // Nếu đọc từ storage thành công và có key, hãy sử dụng chúng.
    if (keysFromStorage.length > 0) {
        apiKeys = keysFromStorage;
        console.log("Đã tải thành công " + apiKeys.length + " API key từ localStorage.");
    } else {
        // Đọc thành công nhưng không có key nào được lưu.
        console.log("Không tìm thấy key trong localStorage. Sử dụng key mặc định (nếu có).");
    }
} else {
    // Không thể đọc từ localStorage (do lỗi hoặc không được hỗ trợ).
    console.log("Không thể tải key từ localStorage. Sử dụng key mặc định (nếu có).");
}

// Log cuối cùng để xác nhận
if (apiKeys.length === 0) {
    console.log("CẢNH BÁO: Không có API key nào được cấu hình để sử dụng.");
} else {
    console.log("Danh sách key cuối cùng sẵn sàng để sử dụng: " + apiKeys.length + " key.");
}