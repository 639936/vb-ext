
let languages = [
    {"id": "zh", "name": "Trung"},
    {"id": "en", "name": "Anh"},
    {"id": "vi", "name": "Việt"},
    {"id": "gen_gemini-2.5-pro", "name": "API (Gemini 2.5 Pro)"},
    {"id": "gen_gemini-2.5-flash-preview-05-20", "name": "API (Flash Preview)"},
    {"id": "gen_gemini-2.5-flash", "name": "API (Flash)"},
    {"id": "gen_gemini-2.5-flash-lite", "name": "API (Flash Lite)"},
    {"id": "vi_tieuchuan", "name": "Việt (Tiêu chuẩn)"},
    {"id": "vi_NameEng", "name": "Việt (Name English)"},
    {"id": "vi_sac", "name": "Truyện Sắc"},
    {"id": "vi_vietlai", "name": "Viết Lại Convert"},
    {"id": "vi_layname", "name": "Lấy Name trong chương"},
    {"id": "vi_xoacache", "name": "Xóa Cache Chương Này"} 
];