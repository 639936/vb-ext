let languages = [
    {"id": "zh", "name": "Trung"},
    {"id": "en", "name": "Anh"},
    {"id": "vi", "name": "Việt"},
    {"id": "vi_tieuchuan", "name": "Việt (Tiêu chuẩn)"},
    {"id": "vi_sac", "name": "Việt (Truyện Sắc)"},
    {"id": "vi_NameEng", "name": "Việt (Name English)"},
    {"id": "vi_vietlai", "name": "Việt (Viết Lại Convert)"},
    {"id": "vi_xoacache", "name": "Xóa Cache Chương Này"} 
];