
function execute(url) {
    var content = "Để quản lý API key (Thêm/Xóa), vui lòng sử dụng chức năng TÌM KIẾM của extension này.";
    return Response.success(content);
}